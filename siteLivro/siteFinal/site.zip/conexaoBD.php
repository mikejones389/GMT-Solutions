
<?php
$db = mysqli_connect('162.241.39.192','gmtmarke_teste','@gmtifsp', 'gmtmarke_projeto_livraria');
if (!$db)
{
echo 'Não deu para conectar ao Banco de Dados';
exit;
}
?>