<?
// Desenvovildo por Andr� Luis
// Contato : djinn22001@yahoo.com.br / stopa190@hotmail.com
//  www.ajaxdesign.webege.com      

$gerar = rand(1,99999);
echo "<img name='captcha_img' id='captcha_img' src='captcha/captcha.$gerar.php' width='150' height='50' />";
?>