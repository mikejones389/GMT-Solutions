<?php

if($_SERVER['REQUEST_METHOD'] == 'POST'){

    header('Content-type: application/json');

    // TOKEN
    
    $api_token = $_POST["api_token"];
    $api_cd_usuario = $_POST["api_cd_usuario"];
    $api_nm_usuario = $_POST["api_nm_usuario"];
    $api_sexo = $_POST["api_sexo"];
    $api_dt_nasc = $_POST["api_dt_nasc"];
    $api_login = $_POST["api_login"];
    $api_senha = md5($_POST["api_senha"]);
    

    if($api_token == 'validarLogin'){

        // Conexﾃ｣o com o BD

        require_once('dbConnect.php');

        // DEFINIR UTF8 PARA A CONEXﾃグ

        mysqli_set_charset($conn, $charset);

        $response = array();
        
        $sql = "SELECT cd_usuario, login, senha FROM usuario WHERE login like '$api_login' and senha like '$api_senha';"; 

        $stmt = mysqli_prepare($conn, $sql);

        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        mysqli_stmt_bind_result($stmt, $id, $login, $senha);

        //APRENSENTA OS DADOS DA CONSULTA
        //var_dump($stmt);

        if(mysqli_stmt_num_rows($stmt) > 0){

            while(mysqli_stmt_fetch($stmt)){
                array_push($response, array("id" => $id, "login" => $login, "senha" => $senha));
            }
            $response["Login"]= true;
            $response["ID"]= $id;
            echo json_encode($response);

        }else{
            $response["Login"] = false;
            $response["SQL"] = $sql;
            echo json_encode($response);
        }
    }
    
    else if($api_token == 'cadastrar'){
        
        // Conexﾃ｣o com o BD

        require_once('dbConnect.php');

        // DEFINIR UTF8 PARA A CONEXﾃグ

        mysqli_set_charset($conn, $charset);

        $response = array();
        
        $sql = "INSERT INTO usuario(nm_usuario, sexo, data_nascimento, login, senha)
         VALUES ('$api_nm_usuario', '$api_sexo', '$api_dt_nasc', '$api_login', '$api_senha');"; 

        $stmt = mysqli_prepare($conn, $sql);

        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        mysqli_stmt_bind_result($stmt, $id, $nm_usuario, $login, $senha);

        //APRENSENTA OS DADOS DA CONSULTA
        //var_dump($stmt);
        $id=mysqli_stmt_insert_id($stmt);
        if(mysqli_stmt_affected_rows($stmt) > 0){
            
            $response["Cadastro"]= true;
            $response["NOME"]= $api_nm_usuario;
            $response["SEXO"]= $api_sexo;
            $response["ID"]=$id;
            echo json_encode($response);

        }else{
            $response["Cadastro"] = false;
            $response["SQL"] = $sql;
            echo json_encode($response);
        }
        
    }
    
    else if($api_token == 'consultar'){

        //CONEXÃO COM O BDD
        
        require_once('dbConnect.php');
        
        //DEFINIR UTF8 PARA A CONEXÃO
         
        mysqli_set_charset($conn, $charset);
        
        $response = array();
        
        $sql = "SELECT cd_usuario, nm_usuario, sexo, login, senha FROM usuario WHERE cd_usuario = $api_cd_usuario;";
        
        $stmt = mysqli_prepare($conn, $sql);
        
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        mysqli_stmt_bind_result($stmt, $cd_usuario, $nm_usuario, $sexo, $login, $senha);
        
        //APRESENTA OS DADOS DA CONSULTA
        //var_dump($stmt);
        
        
        if(mysqli_stmt_num_rows($stmt) > 0){
            
            while(mysqli_stmt_fetch($stmt)){
                array_push($response, array("cd_usuario" => $cd_usuario, "nm_usuario" => $nm_usuario, "sexo" => $sexo, "login" => $login, "senha" => $senha));
            }
            $response["RESULTADO"] = true;
            $response["ID"] = $cd_usuario;
            $response["nm_usuario"] = $nm_usuario;
            $response["SEXO"] = $sexo;
            echo json_encode($response);
            
        }
        else{
            $response["RESULTADO"] = false;
            $response["SQL"] = $sql;
            echo json_encode($response);
        }
    }
    else {
        $response['auth_token'] = false;
        echo json_encode($response);
    }
}
else {
    $respones['auth_method'] = false;
}
?>