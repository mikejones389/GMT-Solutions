<html xmlns="http://www.w3.org/1999/xhtml" lang="pt" class=" js no-flexbox flexbox-legacy canvas canvastext webgl no-touch geolocation indexeddb hashchange history draganddrop rgba hsla multiplebgs backgroundsize borderimage borderradius boxshadow textshadow opacity cssanimations csscolumns cssgradients cssreflections csstransforms csstransforms3d csstransitions fontface generatedcontent video audio applicationcache svg inlinesvg smil svgclippaths"><head><link rel="dns-prefetch" href="https://f.monetate.net"><link rel="dns-prefetch" href="https://sb.monetate.net"><script type="text/javascript" async="" src="https://www.google-analytics.com/plugins/ua/ec.js"></script><script type="text/javascript" async="async" src="https://dpm.demdex.net/id?d_visid_ver=1.5.4&amp;d_rtbd=json&amp;d_ver=2&amp;d_orgid=7ADA401053CCF9130A490D4C%40AdobeOrg&amp;d_nsid=0&amp;d_mid=65243287537766827079115382408587739478&amp;d_cb=s_c_il%5B1%5D._setAudienceManagerFields"></script><script type="text/javascript" async="" charset="utf-8" id="utag_447" src="https://p.teads.tv/teads-fellow.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_395" src="https://adidas.virtualinteractions.com.br/script/tracking.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_358" src="//d.impactradius-event.com/A1188131-1823-40b0-bd8a-40f4706cde781.js"></script><script type="text/javascript" src="//zn6mcrij6xncfajof-adidastrial.siteintercept.qualtrics.com/WRSiteInterceptEngine/?Q_ZID=ZN_6McRij6XnCfajoF&amp;Q_LOC=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start"></script><script type="text/javascript" async="" charset="utf-8" id="utag_394" src="https://10977635.collect.igodigital.com/collect.js"></script><script src="https://connect.facebook.net/signals/config/680435655455279?v=2.9.14&amp;r=stable" async=""></script><script type="text/javascript" async="" charset="utf-8" id="utag_247" src="https://connect.facebook.net/en_US/fbevents.js"></script>



<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Content-Language" content="pt-BR">

	


	<meta http-equiv="x-dns-prefetch-control" content="on">	
	
		
		<link rel="dns-prefetch" href="//demandware.edgesuite.net">
	
		
		<link rel="dns-prefetch" href="//hp.static.adidas.com">
	
		
		<link rel="dns-prefetch" href="//tags.tiqcdn.com">
	
		
		<link rel="dns-prefetch" href="//cdn.optimizely.com">
	
		
		<link rel="dns-prefetch" href="//adidas.ugc.bazaarvoice.com">
	
		
		<link rel="dns-prefetch" href="//maps.googleapis.com">
	




































































	
	
	
	
	
	
	
		<meta property="og:site_name" content="adidas Brasil">
	
		<meta property="og:title" content="adidas Brasil | Site Oficial">
	
		<meta property="og:url" content="https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COSummary2-Start">
	
		<meta property="og:description" content="Compre em nossa loja on-line: roupas, tênis e acessórios esportivos da adidas criados com tecnologia, design e conforto">
	
	
	





<title>



adidas Brasil | Site Oficial



</title>



<!--[if lte IE 8]>
<script type="text/javascript">
	document.createElement('segment');
</script>
<![endif]-->





<!-- build page type:checkout -->

<link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/fonts.css" type="text/css" rel="stylesheet">


<!-- checkout -->
<link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/adidas-build-COMMON.css" type="text/css" rel="stylesheet">

<link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/adidas-build-checkout.css" type="text/css" rel="stylesheet">

<!--[if lt IE 10]>
<link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/adidas-build-COMMON-iefix.css" type="text/css" rel="stylesheet" />
<![endif]-->


<link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/local.css" type="text/css" rel="stylesheet">

<!--[if IE 8]><link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/ie8_global.css" type="text/css" rel="stylesheet" /><![endif]-->
<!--[if IE 9]><link href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/css/ie9_global.css" type="text/css" rel="stylesheet" /><![endif]-->




<link rel="apple-touch-icon" sizes="180x180" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/images/favicons/apple-touch-icon.png">
<link rel="shortcut icon" type="image/png" sizes="180x180" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/default/dw12c05e0c/images/favicons/favicon.png">
<link rel="shortcut icon" type="image/png" sizes="32x32" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/default/dwcc8a4d27/images/favicons/favicon-32x32.png">
<link rel="shortcut icon" type="image/png" sizes="16x16" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/default/dwdddea838/images/favicons/favicon-16x16.png">
<link rel="manifest" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/default/dw7ae1029b/images/favicons/manifest.json">
<link rel="icon" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/default/dw46916cb7/images/favicons/favicon.ico">
<meta name="msapplication-config" content="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/default/dw0c542321/images/favicons/browserconfig.xml">
<meta name="theme-color" content="#fff">
<link href="https://plus.google.com/101842039723189178420" rel="publisher">




<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">




<meta name="robots" content="noindex, follow">


<meta property="fb:app_id" content="313020398793457">

<meta name="format-detection" content="telephone=no">











<!--[if lte IE 8]>
<script src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/iefix.js" type="text/javascript"></script>
<script src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/json2.min.js" type="text/javascript"></script>
<![endif]-->


<iframe src="javascript:void(0)" title="" style="width: 0px; height: 0px; border: 0px; display: none;"></iframe><iframe src="javascript:void(0)" title="" style="width: 0px; height: 0px; border: 0px; display: none;"></iframe><img id="_0" width="1" height="1" border="0" src="https://abandonment.saas.seewhy.com:443/abandonment2/WE/seewhy.nogif/0.6994695570467688?Event=WebEvent&amp;CustomerCode=1561934516&amp;Server=www.adidas.com.br&amp;DefaultPageName=%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start&amp;Referrer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCODelivery-Start&amp;SessionID=626C6179-53A0-4397-8C23-A36FC671E10E&amp;FunnelLevel=4&amp;Section=&amp;UserID=gudamota%40gmail.com&amp;Product=&amp;Quantity=0&amp;OrderNumber=&amp;Value=251.56&amp;PageName=&amp;ReturnToLink=www.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCart-UpdateItems%3Fpid_1%3DED6242_290%26qty_1%3D1.0&amp;Custom1=Gustavo&amp;Custom2=&amp;Custom3=&amp;Custom4=&amp;Custom5=BRL&amp;Custom6=&amp;Custom7=&amp;Custom8=&amp;Custom9=&amp;Custom10=&amp;Custom11=0&amp;Custom12=0&amp;Custom13=0&amp;Custom14=0&amp;Custom15=0&amp;Custom16=0&amp;Custom17=0&amp;Custom18=0&amp;Custom19=0&amp;Custom20=0&amp;ClickstreamFlag=0&amp;ClientTimeAndTZ=1575073944075~120&amp;Version=3.6.14/331/DW&amp;CYBK001ItemName=Jaqueta%20Asymm&amp;CYBK001ItemDesc=Estilo%20cl%26aacute%3Bssico%20com%20um%20toque%20moderno.%20Blocos%20de%20cores%20estilo%20retr%26ocirc%3B%20criam%20uma%20grande%20estampa%20de%20grade%20na%20superf%26iacute%3Bcie%20desta%20jaqueta.%20Ela%20%26eacute%3B%20feita%20de%20malha%20leve%20e%20macia%20com%20corte%20quadrado.%20O%20contorno%20do%20logo%20Trefoil%20bordado%20completa%20o%20visual.&amp;CYBK001ItemPageURL=www.adidas.com.br%2Fjaqueta-asymm%2FED6242_290.html&amp;CYBK001ItemPrice=298.73&amp;CYBK001ItemQuantity=1.0&amp;CYBK001ItemID=ED6242_290&amp;CYBK001ItemImageURL=www.adidas.com.br%2Fdw%2Fimage%2Fv2%2Faaqx_prd%2Fon%2Fdemandware.static%2FSites-adidas-BR-Site%2FSites-adidas-products%2Fpt_BR%2Fv1575016193036%2Fzoom%2FED6242_21_model.jpg%3Fsw%3D110%26sh%3D110%26sm%3Dfit&amp;BasketAppend=0"><script type="text/javascript" async="" charset="utf-8" id="tealium-tag-7110" src="https://www.google-analytics.com/analytics.js"></script><script type="text/javascript" src="https://se.monetate.net/js/2/a-24f48522/p/adidas.br/custom.js"></script><script src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/require.js" type="text/javascript"></script>
<script src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/jquery-1.8.3.min.js" type="text/javascript"></script>
<script type="text/javascript">
jQuery.curCSS = jQuery.css;
</script>
<!--[if lte IE 9]>
<script src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/jquery.placeholder.js" type="text/javascript"></script>
<script type="text/javascript">jQuery(function () { try { jQuery('input, textarea').placeholder(); } catch(e) {} });</script>
<![endif]-->

<!-- checkout -->
<script type="text/javascript">
window.app=jQuery.extend(window.app || {}, {isBuilded:true,bundlesRequired:
["https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/adidas-build-COMMON.js"

,"https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/adidas-build-checkout.js"

]});
</script>

<script src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/web-event.js" type="text/javascript"></script>




<script type="text/javascript">






(function (app) {
'use strict';
app.constants = {};
app.resources = {};
app.minicart = {};
app.URLs = {};
app.minicart.oldLayerToNew = (function (map) {
return function (layer, defaultValue) {
return layer && map[layer] ? map[layer] : defaultValue;
};
}({
"minicart": "Mini cart",
"overlay": "Add To Bag overlay",
"straightcart": "Straight to Cart"
}));
app.isMobile = true;
app.isAdidas = true;
app.isReebok = false;
app.minicart.url = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-MiniAddProduct";
app.minicart.productCountUrl = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-ProductCount";
app.URLs.personalizedBasketCheck = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-ValidatePersonalizationBasket";
app.URLs.deliveryStart = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-Start";
app.URLs.getFullProductUrl = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-Show";
app.URLs.getProductUrl = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-Show";
app.URLs.getVariants = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-GetVariants";
app.URLs.getMasterAvailability = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-GetMasterAvailability";
app.URLs.getAvailability = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-GetAvailability";
app.URLs.loadingSmallImg = "/on/demandware.static/Sites-adidas-BR-Site/-/default/dwd45b5b0e/images/loading-small.gif";
app.URLs.formatMoney = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-FormatPrices";
app.URLs.removeImg = "/on/demandware.static/Sites-adidas-BR-Site/-/default/dw3cf60f08/images/icon_remove.gif";
app.URLs.getProductTileList = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/ProductTiles-GetTiles";
app.URLs.getAssetContent = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Page-Include";
app.URLs.jsonConfiguratorLink = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Configurator-GetJsonURL";
app.URLs.sendToFriend = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/SendToFriend-Start";
app.URLs.deliverySubmits = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-Submits";
app.URLs.blankImg = "/on/demandware.static/Sites-adidas-BR-Site/-/default/dw7f184d51/images/blank.gif";
app.URLs.showImage = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-ShowImage";
app.URLs.searchSuggestURL = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/SearchAuxiliar-GetSuggestions";
app.URLs.viewAllSuggestURL = "/search";
app.URLs.showCartURL = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-Show";
app.URLs.lookupEmail = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-LookupEmail";
app.URLs.paymentPage = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COSummary-Start";
app.URLs.loginValidationURL = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/ShopRunner-ValidateToken";
app.URLs.getShipmentMethods = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-GetShippingOptions";
app.URLs.storeSelectedPostamat = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COShipping-StorePostamat";
app.URLs.savePostNumberID = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/OmniChannel-setPostNumberId";
app.URLs.fillInScheduledDelivery = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-FillInScheduledDelivery";
app.URLs.getAddressTemplate = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-GetAddressTemplate";
app.URLs.getEPOCHAvailability = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/OmniChannel-GetEPOCHAvailability";
app.URLs.getUspBar = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Page-GetUSPBar";
app.URLs.productComparisonPage = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/ProductAuxiliar-Comparison";
app.URLs.setSubscriptionFlagUrl = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COPayment-SetNewsletterFlag";
app.URLs.getAllocationTimer = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-ShowAllocationTimer";
app.URLs.createComingSoonSignup = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/SCV-CreateCommingSoonSignup";
app.URLs.PERSONALIZATION_BASE_URL = "https://cfg.adidas.com";
app.URLs.deleteUnavailableProducts = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/OmniChannel-DeleteUnavailableProducts";
app.URLs.getSalesContracts = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COPayment-GetSalesContract";
app.URLs.getAvailableSizes = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-GetAvailableSizes";
app.URLs.PERSONALIZATION = {
ppr: "/configurator/services/miadidas-configurator/ppdo/article/{article}/region/{region}/channel/{channel}/partner/{partner}",
rr: "/configurator/services/miadidas-configurator/pRecipeService/recipeIdent/{recipeIdent}/region/{region}/channel/{channel}/partner/{partner}",
plr: "/configurator/services/miadidas-configurator/sldProfanity/productTypeId/{productType}/specialType/Personalization/region/{region}/channel/{channel}/partner/{partner}",
ic: "/configurator/services/miadidas-configurator/pRecipeService/validateinventory/deductInventory/{deductInventory}/region/{region}/channel/{channel}/partner/{partner}"
};
app.URLs.getBVReviews = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/ProductAuxiliar-GetBVReview";
app.URLs.HelpSuggest = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Help-Suggest?q=";
app.URLs.editOrderEmail = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/OrderTracker-EditOrderEmail";
app.URLs.editOrderPhone = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/OrderTracker-EditOrderPhone";
app.URLs.cartUpdateItems = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-UpdateItems";
app.URLs.orderTrack = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Order-Track";
app.URLs.updateColorVariation = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Wishlist-GetColorVariation";
app.URLs.addressList = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Address-List";
app.URLs.login = "/account-login";
// Preferences
app.displayCarrierName = true;
app.CommissionJunctionEnable = false;
app.noneCom = false;
app.shoprunnerEnabled = false;
app.epochShipFromStoreEnabled = false;
app.shoprunnerRetailerID = "null";
app.shoprunnerEnvironmentID = "1";
app.minimumInstallmentAmount = "40.0";
app.guestWishlistLifeAgeDays = "30 day";
app.wishlistCookieName = "wishlist";
app.stickyBag = "true";
app.epochShipFromStoreEnabled = "false";
app.applyLazyLoadFix = "true";
app.enableProductPriceTracking = "true";
app.iccdSourceID = "null";
app.enableSalesContract = false;
app.enableBINCheckForInstallments = false;
app.rbkStyleRefreshEnabled = "false";
app.contentURL = undefined;
/*constants*/
app.constants.AVAIL_STATUS_IN_STOCK="IN_STOCK";
app.constants.AVAIL_STATUS_PREORDER="PREORDER";
app.constants.AVAIL_STATUS_BACKORDER="BACKORDER";
app.constants.AVAIL_STATUS_NOT_AVAILABLE="NOT_AVAILABLE";
app.constants.AVAIL_STATUS_PREVIEW="PREVIEW";
app.constants.LOCALE="pt_BR";
app.constants.LOCALE_COUNTRY="BR";
app.constants.SITE_ID="adidas-BR";
app.constants.LAZY_LOAD_SPACE="400";
app.constants.PRODUCT_MAX_QTY_THRESHOLD="3";
app.constants.GENERIC_MAX_QTY_THRESHOLD="0";
app.constants.CURRENCY_CODE = "BRL";
app.constants.HIDE_SHIPPING_METHODS_ON_CART = true;
app.constants.GLOBAL_TEMPLATE = "true";
app.constants.ADDRESS_VALIDATION_PROVIDER = "No validation";
app.constants.ADDRESS_DOCTOR_IMPROVEMENT = "false";
app.constants.ADDRESS_DOCTOR_POPUP_TITLE = "Verifique o seu endereço";
app.constants.DYNAMIC_TERMS_CONDITIONS = false;
app.constants.DEFAULT_RADIUS = 100;
app.constants.USE_SPLITTED_DELIVERY = false;
app.constants.BV_COLLAPSE_REVIEWS = false;
app.constants.UPS_INTERVAL_MESSAGING = 3;
app.constants.PERSONALIZATION_CHANNEL = "1";
app.constants.PERSONALIZATION_PARTNER = "null";
app.constants.GOOGLE_MAP_API = "AIzaSyCEzI0b4zd7PAVIorzVFaf_UVrVFyrZGPg";
/*resources*/
app.resources["LIMIT_QUANTITY"]="Limitado a {0} item por compra";
app.resources["MISSINGVAL"]="Por favor, insira {0}";
app.resources["SERVER_ERROR"]="Falha de conexão com o servidor ";
app.resources["MISSING_LIB"]="jQuery é indefinido.";
app.resources["MISSING_APP_LIB"]="app is undefined.";
app.resources["BAD_RESPONSE"]="Erro de interpretação";
app.resources["INVALID_PHONE"]="Por favor, informe um número de telefone válido.";
app.resources["REMOVE"]="Remover";
app.resources["QTY"]="Quantidade";
app.resources["SEARCH_TEXT"]="Procurar";
app.resources["NOHITS_SEARCH_TEXT"]="Procurar";
app.resources["PRICE_EXAMPLE"] = 'R$ 1.234,00';
app.resources["SHIPPINGCOSTFREE"] = "Livre";
app.resources["NO_REVIEWS"]="Não há comentários para este produto";
app.resources["STICKVOGEL_POPUP_TITLE"]="Custo de Personalização";
app.resources["MOBILE_COOKIE_EXPIRATION_DATE"] = "null";
app.resources["DEV_INSTANCE_WARNING"] = "This is NOT A LIVE SITE. This is test environment. Do NOT place orders.";
app.resources["SIZE_LABEL"] = "Tamanho";
app.resources["GLOBAL_UPDATE"] = "Atualizar";
app.resources["GLOBAL_LOADING"] = "Loading";
app.resources["GLOBAL_CONFIRM_UPDATE"] = "Confirm your update";
app.resources["CLICKCOLLECT_UNAVAILABLE_TITLE_MESSAGE"] = "Because of an update to your bag, click & collect is no longer available and delivery times have changed.";
app.resources["CLICKCOLLECT_UNAVAILABLE_MESSAGE"] = "Please select one of the updated delivery options and time-slots below.";
app.resources["CLICKCOLLECT_AVAILABLE_TITLE_MESSAGE"] = "Because of an update to your bag, click & collect and new delivery times and are now available.";
app.resources["CLICKCOLLECT_AVAILABLE_MESSAGE"] = "Please select one of the updated delivery options and time-slots below.";
app.resources["MINICART_CLICKCOLLECT_UNAVAILABLE"] = "With this update to your bag, click & collect is now available and your delivery times will change. You will be taken back to the delivery page.";
app.resources["MINICART_CLICKCOLLECT_AVAILABLE"] = "With this update to your bag, click & collect will no longer be available and your delivery times will change. You will be taken back to the delivery page.";
app.resources["CLICKCOLLECT_SCHEDULED_DELIVERY_UNAVAILABLE_TITLE_MESSAGE"] = "Because of an update to your bag, click & collect and sechulded delivery are no longer available and delivery times have changed.";
app.resources["CLICKCOLLECT_SCHEDULED_DELIVERY_UNAVAILABLE_MESSAGE"] = "Please select one of the updated delivery options and time-slots below.";
app.resources["CLICKCOLLECT_SCHEDULED_DELIVERY_AVAILABLE_TITLE_MESSAGE"] = "Because of an update to your bag, click & collect, scheduled delivery and new delivery times  are now available.";
app.resources["CLICKCOLLECT_SCHEDULED_DELIVERY_AVAILABLE_MESSAGE"] = "Please select one of the updated delivery options and time-slots below.";
app.resources["CLICKCOLLECT_AVAILABLE_TIMEINTERVAL_TITLE_MESSAGE"] = "Because you updated your bag, new delivery times are now available.";
app.resources["CLICKCOLLECT_AVAILABLE_TIMEINTERVAL_MESSAGE"] = "Please select one of the updated delivery time-slots";
app.resources["MINICART_TIMEINTERVAL"] = "With this update, your delivery times will change. You will be taken back to the delivery page.";
app.resources["MINICART_CLICKCOLLECT_SCHEDULED_DELIVERY_UNAVAILABLE"] = "With this update to your bag, click & collect and scheduled delivery will no longer be available and your delivery times will change . You will taken back to the delivery page.";
app.resources["MINICART_CLICKCOLLECT_SCHEDULED_DELIVERY_AVAILABLE"] = "With this update to your bag, click & collect and scheduled delivery are now available and your delivery times will change. You will be  taken back to the delivery page.";
app.resources["PROCESSING_PAYMENT"] = "Processando pagamento";
app.resources.PERSONALIZATION_TEXTS = {
'nameAndNumber': "Acrescentar nome e número",
'pName-pNumber.nameAndNumber.textwithDropDown': "Seu ídolo",
'pName-pNumber.nameAndNumber': "Seu nome / número",
'pName-pNumber.nameOfnameAndNumber': "Nome",
'pName-pNumber.numberOfnameAndNumber': "00",
'pNumber.nameAndNumber.textNumber': "Texto",
'pName-pName-pNumber.nameAndNumber.textwithDropDown': "Seu ídolo",
'pName-pName-pNumber.nameAndNumber': "Seu nome / número",
'pName-pName-pNumber.nameOfnameAndNumber': "personalization.pName-pName-pNumber.nameOfnameAndNumber.displayText",
'pName-pName-pNumber.numberOfnameAndNumber': "personalization.pName-pName-pNumber.numberOfnameAndNumber.displayText",
'pName-pName-pNumber.nameOnly': "personalization.pName-pName-pNumber.nameOnly.displayText",
'pNumber.pNumber': "00",
'left_text.text': "Pé esquerdo (A-Z, 0-9)",
'right_text.text': "Pé direito (A-Z, 0-9)"
};
app.resources["GORKY_PARK_ADDRESS"] = "";
app.resources["GORKY_PARK_NAME"] = "Gorky Park";
/* postal code lookup*/
app.resources["ENABLE_POSTAL_CODE_LOOKUP"] = false;
app.resources["POSTAL_CODE_LOOKUP_MANUAL"] = false;
app.resources["POSTAL_CODE_LOOKUP_BILLING_MANUAL"] = null;
app.resources["CODELIVERY_POSTAL_CODE_LOOKUP_MANUAL"] = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-PostalCodeLookUpManual";
app.resources["POSTAL_LOADING"] = "Loading...";
app.resources["POSTAL_FINDADDRESS"] = "Encontrar o endereço";
app.resources["POSTAL_NO_ADDRESS_SUGGESTION"] = "Adderess not found? <span class='postal-enter-manually'>Enter manually</span>";
app.resources["POSTAL_NO_ADDRESS_SUGGESTION_MOBILE"] = "Adderess not found? Enter manually";
app.resources["SELECT_YOUR_ADDRESS"] = "Selecione seu endereço";
app.resources["EDIT_YOUR_ADDRESS"] = "Editar Endereço";
app.resources["POSTAL_LOADING_ERROR_SELECT_ADDRESS"] = "Please choose your address";
app.resources["ADDRESS_SUGGESTION_FAIL_SERVICE"] = "Nós não encontrar o seu endereço. Favor digitar abaixo.";
app.resources["PRELIMINARYCONTRACT_ERROR_MESSAGE"]="forms.salescontract.prelimerror.message";
app.resources["SALESCONTRACT_ERROR_MESSAGE"]="forms.salescontract.saleserror.message";
/*product availability messages*/
app.resources["IN_STOCK"]="Em estoque";
app.resources["QTY_IN_STOCK"]="{0} Item(s) em estoque";
app.resources["PREORDER"]="<span style=\"color:green;font-weight:bold;\">Encomendar agora</span>Somente {0} dias restantes para pré-venda";
app.resources["QTY_PREORDER"]="{0} item(s) estão disponíveis para pré-venda.";
app.resources["REMAIN_PREORDER"]="Os demais itens estão disponíveis para pré-venda.";
app.resources["BACKORDER"]="Devolver";
app.resources["QTY_BACKORDER"]="Devolver {0} item(s)";
app.resources["REMAIN_BACKORDER"]="Os demais itens estão disponíveis para devolução.";
app.resources["NOT_AVAILABLE"]="Este item não está disponível no momento.";
app.resources["REMAIN_NOT_AVAILABLE"]="Os demais itens não estão disponíveis. Por favor, exclua-os.";
app.resources["IN_STOCK_DATE"]="A data prevista para chegada em estoque é {0}.";
app.resources["NON_SELECTED"]="Não selecionado";
app.resources["MISSING_VAL"]="Selecione {0}";
app.resources["SIZECHART_TITLE"]="Ver Tabela de Tamanhos";
app.resources["SEND_TO_FRIEND"]="Enviar para um amigo";
app.resources["CHANGE_EMAIL_ADDRESS"]="Change email address";
app.resources["CHANGE_PHONE_NUMBER"]="Change phone number";
app.resources["QTY_LIMIT_MESSAGE"]="Restam apenas {0} no estoque";
app.resources["LOW_LIMIT_MESSAGE"]="Baixo estoque";
app.resources["REORDER"]="Re-order";
/*add resources for preview*/
app.resources["PREVIEW"]="<span class=\"callout-bar-headline\">EM BREVE!</span><span class=\"callout-bar-short\"><span class=\"callout-bar-text\">Disponível em </span><span class=\"callout-bar-day-count\">{0} dias</span></span>";
app.resources["COMING_SOON_IN_HOURS_AND_MINUTES"]="<span class=\"callout-bar-headline\">EM BREVE!</span><span class=\"callout-bar-short\"><span class=\"callout-bar-text\">Disponível em </span><span class=\"callout-bar-day-count\">{0} hora(s) e {1} minuto(s)</span></span>";
app.resources["COMING_SOON_IN_MINUTES"]="<span class=\"callout-bar-headline\">EM BREVE!</span><span class=\"callout-bar-short\"><span class=\"callout-bar-text\">Disponível em </span><span class=\"callout-bar-day-count\">{0} minuto(s)</span></span>";
app.resources["ADD_TO_CART_COMING_SOON"]="Em breve";
app.resources["ADD_TO_CART_PREORDER"]="Pré-venda";
/* bonus products messages*/
app.resources["BONUS_PRODUCTS"]="Produtos bônus(s)";
app.resources["SELECT_BONUS_PRODUCT"]="Selecione";
app.resources["BONUS_PRODUCT_MAX"]="O número máximo de produtos bônus foi selecionado. Por favor, remova um para adicionar outro produto bônus.";
app.resources['QUICKVIEW_TITLE']="Visualização rápida";
app.resources['ADD_TO_CART_BUTTON_TITLE']="Adicionar ao carrinho ";
app.resources['PRE_ORDER_BUTTON_TITLE']="Pré-venda";
app.resources['BACK_ORDER_BUTTON_TITLE']="Backorder add to bag";
app.resources['UPDATE_BUTTON_TITLE']="Atualizar";
/*Comparison*/
app.resources["COMPARE_SINGLE"] ="{0}{1} selecionados";
app.resources["COMPARE_PLURAL"] ="{0}{1} selecionados";
app.resources["COMPARE_INFORM"] ="0{0} selecionados";
app.resources["QUICKVIEW_TITLE_WISHLIST"]="Escolha os detalhes";
/* miproduct page*/
app.resources["BLOCKER_MESSAGE_title"]="You are leaving the current page.";
app.resources["BLOCKER_MESSAGE_message"]="Your design has not been saved.";
app.resources["BLOCKER_MESSAGE_button_continue"]="Continue without saving";
app.resources["BLOCKER_MESSAGE_button_cancel"]="Cancel";
app.resources["BLOCKER_MESSAGE_survey_text"]="Help us make customization even easier.<br />Please tell us what you think.";
app.resources["BLOCKER_MESSAGE_survey_linktext"]="Take our survey";
app.resources["DESIGN_GALLERY_TITLE"]="Design Search";
app.resources["DESIGN_GALLERY_CLOSE1"]="The";
app.resources["DESIGN_GALLERY_CLOSE2"]="Gallery";
/* personalization*/
app.resources["LEARN_MORE_URL"] = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Page-Include?cid=personalization-learn-more";
app.resources["LEARN_MORE_URL_FTW"] = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Page-Include?cid=personalization-learn-more-ftw";
app.resources["LEARN_MORE_TITLE"] = "?";
app.resources["PERSONALIZED_PRODUCT_BASKET_CHECK_URL"] = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-PersonalizedProductCountInBasket?size=13";
app.resources["TOO_MANY_PERSONALIZED_IN_BASKET"] = "Você excedeu a quantidade de produtos personalizados adicionados os carrinho de compras. Por favor, tente novamente.";
app.resources["OUT_OF_STOCK"] = "Desculpe, uma ou mais LETRAS ou NÚMEROS não possui estoque disponível no momento. Por favor, tente novamente.";
app.resources["OUT_OF_STOCK_SPECIFIC"] = "Desculpe {0} está indisponível no momento. Por favor, tente usar outra letra ou número.";
app.resources["OUT_OF_STOCK_LETTER"] = "Desculpe {0} está indisponível no momento. Tente outra letra.";
app.resources["OUT_OF_STOCK_NUMBER"] = "Desculpe {0} está indisponível no momento. Tente outro número.";
app.resources["BADGE_OUT_OF_STOCK"] = "Desculpe, um ou mais ESCUDOS que você escolheu não possui estoque disponível no momento. Por favor, tente novamente.";
app.resources["SERVICE_ERROR"] = "Opa, algo deu errado. Poderia, por favor tentar novamente?";
app.resources["PERSONALIZATION_BASE_URL"] = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/PersonalizationService-Start";
app.resources["NOT_VALID_INPUT_PERSONALIZATION"] = "Desculpe, texto inválido. Por favor, tente novamente ou substitua o texto.";
app.resources["NOT_VALID_FOR_ONLY_NAME_INPUT_PERSONALIZATION"] = "Desculpe, este campo só pode ser preenchido com texto.";
app.resources["NOT_VALID_FOR_ONLY_NUMBERS_INPUT_PERSONALIZATION"] = "Desculpe, este campo só pode ser preenchido com números.";
app.resources["NOT_SUPPORTED_INPUT_PERSONALIZATION_SINGULAR"] = "O símbolo {0} não está disponível em nosso sistema. Desculpe. Use um novo caractere e tente novamente.";
app.resources["FORBIDDEN_INPUT_PERSONALIZATION"] = "Desculpe, mas {0} não está de acordo com a nossa política de personalização. Tente outra alternativa.";
app.resources["NOT_VALID_INPUT_SPECIFY_VALUE"] = "Por favor, especifique o valor";
app.resources["PERSONALIZATION_ADD_A_BADGE"] = "Acrescentar um escudo";
app.resources["PERSONALIZATION_PREVIEW"] = "Visualização";
app.resources["MIADIDAS_BASE_URL"] = "http://cfg.adidas.com";
app.resources["CLEAR_ALL"] = "Limpar tudo";
app.resources["FOOTWEAR_HEADER"] = "";
app.resources["MORE_INFORMATION"] = "MORE INFORMATION";
/* search suggestions*/
app.resources["ENABLE_DEMANDWARE_SUGGESTIONS"] = true;
app.resources["ENABLE_CATEGORY_SUGGESTIONS"] = false;
app.resources["ENABLE_PRODUCT_SUGGESTIONS"] = true;
app.resources["MINIMUM_CHARACTERS_FOR_SUGGESTION"] = 3;
app.resources["SEARCH_SUGGESTIONS"] = "Sugestões";
app.resources["CATEGORY_SUGGESTIONS"] = "Categorias";
app.resources["PRODUCT_SUGGESTIONS"] = "Produtos";
app.resources["PRODUCT_SUGGESTIONS_PRICE"] = "Price:";
app.resources["VIEW_ALL_RESULTS_SUGGESTIONS"] = "View All Results";
// redirects
app.resources["REDIRECT_TITLE"] = "You will be redirected";
app.resources["REDIRECT_CTA"] = "CONTINUE";
app.resources["REDIRECT_MESSAGE"] = "to our adidas {0} online shop. This is where you find the widest range of {1} products. Your account details are all the same, but you will have a different shopping bag to fill. In case of questions, a team of specialty sports customer service advisors are here to help.";
app.resources["REDIRECT_HOSTNAMES"] = "y-3,adidasbodycare,adidasspecialtysports,adidashardware";
app.resources["REDIRECT_NAMES"] = "";
/* CO DocumentTypeID validation */
app.resources["FORMS_DOCUMENTTYPEID_NIT_ERROR"] = "Invalid NIT value!";
app.resources["FORMS_DOCUMENTTYPEID_CC_ERROR"] = "Invalid CC value!";
app.resources["FORMS_DOCUMENTTYPEID_CE_ERROR"] = "Invalid CE value!";
app.resources["FORMS_DOCUMENTTYPEID_Pasaport_ERROR"] = "Invalid Passport value!";
app.resources["FORMS_DOCUMENTTYPEID_TI_ERROR"] = "Invalid TI value!";
app.resources["FORMS_DOCUMENTTYPEID_RC_ERROR"] = "forms.documentTypeId.RC.error";
app.resources["FORMS_DOCUMENTTYPEID_TE_ERROR"] = "forms.documentTypeId.TE.error";
app.resources["FORMS_DOCUMENTTYPEID_DIE_ERROR"] = "forms.documentTypeId.DIE.error";
app.resources["FORMS_DOCUMENTTYPEID_NUIP_ERROR"] = "forms.documentTypeId.NUIP.error";
app.resources["FORMS_DOCUMENTTYPEID_NDOP_ERROR"] = "forms.documentTypeId.NDOP.error";
/* PE DocumentTypeID validation */
app.resources["FORMS_DOCUMENTTYPEID_RUC_ERROR"] = "forms.documentTypeId.RUC.error";
app.resources["FORMS_DOCUMENTTYPEID_DNI_ERROR"] = "forms.documentTypeId.DNI.error";
app.resources["FORMS_DOCUMENTTYPEID_CDE_ERROR"] = "forms.documentTypeId.CDE.error";
/* waitlist*/
app.resources["WAITLIST"] = true;
/* expandable block*/
app.resources["EXPANDABLE_READ_MORE"] = "Ver mais";
app.resources["EXPANDABLE_READ_LESS"] = "Ver menos";
/* Adyen*/
app.resources["ADYENERRORS_CARD_EXPIRED"] = "errorforms.adyenencrypted.expiryDate.valueerror";
/*NEWSLETTERS*/
app.resources['VALID_EMAIL_ERROR'] = "Por favor, insira um endereço de e-mail válido ";
app.resources['NEWSLETTER_SUBSCRIBE_URL'] = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Newsletter-Subscribe";
app.resources['NEWSLETTER_SUBSCRIBE_FOOTER_LABEL'] = "CADASTRE-SE, FIQUE POR DENTRO DAS NOVIDADES E GANHE <span>15% de desconto</span>";
app.resources['LEGAL_NEWSLETTER_AGE_CONSENTTYPE'] = "checkbox";
app.resources['SIGNUPANDSAVE_GENERAL_ERROR'] = "Pedimos desculpas. Devido a manutenção do site, este serviço não está disponível no momento.";
app.resources["PRODUCT_ADDED_TO_CART"] ="Produto adicionado ao carrinho";
app.resources["PRODUCT_SELECT_SIZE"] = "Selecionar tamanho";
app.resources["PRODUCT_PLEASE_SELECT_SIZE"] = "Selecione seu tamanho";
app.resources["VIDEO_PLAYLIST_ID"] = "lSGf2BXW2nRS";
app.resources["FORM_REGEXP_EMAIL"] = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z\\d]{2,9}$";
app.resources["FORM_REGEXP_ZIPCODE"] = "^(([0]{1}[1-9]{1}|[1-9]{1}[0-9]{1})[0-9]{3}([-]|\\s)?[0-9]{3})$";
app.resources["FORM_REGEXP_PHONE"] = "^(\\+){0,1}\\d{8,15}$";
app.URLs.getProductUrl = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-Show";
app.URLs.getVariants = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-GetVariants";
app.URLs.getAvailability = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-GetAvailability";
app.URLs.loadingSmallImg = "/on/demandware.static/Sites-adidas-BR-Site/-/default/dw6bcd5404/images/loading-small-mobile.gif";
app.URLs.formatMoney = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Product-FormatPrices";
app.URLs.getAssetContent = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Page-Include";
app.URLs.lookupEmail = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-LookupEmail";
app.URLs.updateShippingMethodAjax = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-UpdateShippingMethodAjax";
app.URLs.cartSummaryBlock = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-GetCartSummaryBlock";
app.URLs.updateCartSummaryBlock = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-UpdateCartSummarySectionWithPayment";
app.URLs.validateCCBIN = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COPayment-ValidateCCBIN";
// shipping
app.resources["SHIPPING_METHOD_DEPENDENCIES"] = "%7B%22dwfrm_delivery_singleshipping_shippingAddress_addressFields_zip%22%3A%20%22postalCode%22%2C%20%22dwfrm_delivery_singleshipping_shippingAddress_addressFields_city%22%3A%20%22city%22%2C%20%22dwfrm_delivery_singleshipping_shippingAddress_addressFields_countyProvince%22%3A%20%22stateCode%22%7D";

app.resources["PROFILE_TERMSCONDITIONS"] = "Termos e Condições";
app.resources["PROFILE_PRIVACYPOLICY"] = "Política de Privacidade";
app.resources["PROFILE_WHATDOESTHATMEAN"] = "What does that mean?";
app.resources["PROMO_CODE_VALIDATION_URL"] = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-Submits";
/*coming soon*/
app.resources["COMING_SOON_GENERAL_ERROR"] = "Desculpe, cadastro indisponível. Por favor, tente novamente mais tarde";
/*OMX*/
app.resources["OMX_IS_USED"] = false;
/*storelocator*/
app.resources["STORELOCATOR_PICKUPINDAYS_PARTONE"] = "Available for pick up in ";
app.resources["STORELOCATOR_PICKUPINDAYS_PARTTWO"] = "working days";
app.resources["SEARCH_HAS_NO_RESULTS"] = "Nós não encontramos nenhum produto que fosse de acordo com seu critério de busca. ";
app.resources["ENABLE_WISHLIST_ON_CART"] = true;
app.resources["ENABLE_WISHLIST_GLOBALLY"] = true;
app.URLs.wishlistAjax = "/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Wishlist-ShowAjax";
app.isPostamatEnabled = false;
app.isCollectPointEnabled = false;
app.isClickCollectEnabled= false;



   	app.resources["COUNTRY_RELY_ON_COOKIE"] = false;

app.disableWorkaroundForTrusteOverlay = false
app.constants.PERSONALIZATION_LOCALE = "pt_BR";

app.isMobile = false;


app.resources["ICCD_AUTH_CHK_0003"] = "Endereço de e-mail inválido";
app.resources["ICCD_AUTH_CHK_0004"] = "Sua senha anterior expirou. Uma nova senha foi enviada por e-mail. Confira sua caixa de entrada para validar e mudar sua senha.";
app.resources["ICCD_AUTH_CHK_0005"] = "Usuário autenticado, mas a conta está bloqueada";
app.resources["ICCD_AUTH_CHK_0006"] = "Usuário autenticado, mas menor que a idade permitida ";
app.resources["ICCD_AUTH_CHK_0008"] = "Parece que o teu endereço de e-mail ou a tua palavra-passe estão incorretos. Queres tentar novamente?";
app.resources["ICCD_AUTH_CHK_0013"] = "Usuário autenticado, mas bloqueado";
app.resources["ICCD_AUTH_CHK_0014"] = "Versão Inválida. Versão não suportada";
app.resources["CCD_RST_PWD_0002"] = "Senha ou nome de usuário incorretos";
app.resources["CCD_RST_PWD_0003"] = "Usuário autenticado, mas a conta está bloqueada";
app.resources["CCD_RST_PWD_0004"] = "Endereço de e-mail inválido";
app.resources["CCD_RST_PWD_0005"] = "Versão Inválida. Versão não suportada";
app.resources["CCD_RST_PWD_0006"] = "Endereço de e-mail inválido";
app.resources["CCD_VLD_RST_PWD_0006"] = "Usuário ou senha incorretos";
app.resources["CCD_VLD_RST_PWD_0007"] = "Versão inválida. Versão não suportada";
app.resources["CCD_VLD_RST_PWD_0008"] = "Cliente com conta bloqueada";
app.resources["ICCD_RST_PWD_0005"] = "Por favor, certifique-se que sua senha possui no mínimo uma letra, um número e no mínimo 8 caracteres";
app.resources["ICCD_RST_PWD_0006"] = "Versão inválida. Versão não suportada";
app.resources["ICCD_CRT_ACCT_0002"] = "Formato de e-mail inválido";
app.resources["ICCD_CRT_ACCT_0003"] = "E-mail existe em nosso banco de dados como e-mail de identificação";
app.resources["ICCD_CRT_ACCT_0004"] = "E-mail existe em nosso banco de dados como e-mail de comunicação";
app.resources["ICCD_CRT_ACCT_0005"] = "Por favor, certifique-se que sua senha possui no mínimo uma letra, um número e no mínimo 8 caracteres";
app.resources["ICCD_CRT_ACCT_0006"] = "Cliente está abaixo da idade mínima permitida, precisa ter pelo menos 18 anos";
app.resources["ICCD_CRT_ACCT_0007"] = "Confirmação de DOB ou idade mínima precisam ser fornecidas";

app.resources["EMAIL_SUGGESTION_DOMAINS"] = ['msn.com', 'bellsouth.net','telus.net', 'comcast.net', 'optusnet.com.au','earthlink.net', 'qq.com', 'sky.com', 'icloud.com','mac.com', 'sympatico.ca', 'googlemail.com','att.net', 'xtra.co.nz', 'web.de','cox.net', 'gmail.com', 'ymail.com','aim.com', 'rogers.com', 'verizon.net','rocketmail.com', 'google.com', 'optonline.net','sbcglobal.net', 'aol.com', 'me.com', 'btinternet.com','charter.net', 'shaw.ca', 'yahoo.com', 'adidas.com'];
app.resources["EMAIL_SUGGESTION_TOPLEVELDOMAINS"] = ["com", "com.au", "com.tw", "ca", "co.nz", "co.uk", "de", "fr", "it", "ru", "net", "org", "edu", "gov", "jp", "nl", "kr", "se", "eu", "ie", "co.il", "us", "at", "be", "dk", "hk", "es", "gr", "ch", "no", "cz", "in", "net", "net.au", "info", "biz", "mil", "co.jp", "sg", "hu", "uk"];
app.resources["EMAIL_SUGGESTION_SECONDARYDOMAINS"] = ["yahoo", "hotmail", "mail", "live", "outlook", "gmx"];
app.resources["EMAIL_SUGGESTION_SUGGESTIONTEXT"] = "Você quis dizer";
app.resources["EMAIL_SUGGESTION_CORRECTEDTEXT"] = "Seu endereço de e-mail foi corrigido";
/* GDPR */
app.enableHeaderSignupOverlayGDPR = false;
app.enableCheckoutNewsletterGDPR = false;
/* Exchanges */

return app;
}(app));app.define&&app.define('app.resources',function(){return app;});


app.URLs.currentMobileUrl = "https://www.adidas.com.br/s/Sites-adidas-BR-Site/dw/shared_session_redirect?url=https%3A%2F%2Fm.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start";
(function (app, init) {
var getWaitLoading = function (callback) {
var loading = 0,
loaded = 0;
return function (script) {
var tid;
loading++;
script.onload = script.onreadystatechange = function() {
if (!this.readyState || this.readyState === "loaded" || this.readyState === "complete") {
if (tid) {
clearTimeout(tid);
}
if (++loaded === loading) {
callback();
}
}
};
tid = setTimeout(function () {
script.onload = script.onreadystatechange = undefined;
if (++loaded === loading) {
callback();
}
}, 1000 * 10);
};
};
app.firstDomReady = new jQuery.Deferred();
jQuery(function () {
app.firstDomReady.resolve();
});
if (app.isBuilded === true) {
var scripts = app.bundlesRequired,
head = document.getElementsByTagName("head")[0] || document.documentElement,
loader = getWaitLoading(function(){
init();
});
for (var i = 0; i < scripts.length; ++i) {
var script = document.createElement('SCRIPT');
script.setAttribute('type','text/javascript');
script.async=true;
script.src=scripts[i];
loader(script);
head.appendChild(script);
}
} else {
init();
}
}(window.app, function () {




app.require.config({
baseUrl: "https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js",
catchError: true,
paths: {

"avplayer": "//www.adidas.com/video/com/assets/js/aplayer",
"ComponentMgr": "core/component/ComponentMgr",
"Component": "core/component/Component",
"PageContext": "utils/PageContext",
"Analytics": "utils/Analytics",
"jstorage": "vendor/jstorage.min"
},
waitSeconds: 0,
map: {
"*": {
"styles": "vendor/require-css",
"instance": "utils/require-instance",
"text": "utils/require-text"
}
},
shim: {
},
deps: [
null,
"jquery",
"app.resources",
"ComponentMgr",
"PageContext",
"Analytics",
"utils/forms",
"core/Application",
"component/analytics/CertonaRecommendations",
"vendor/modernizr.custom",
"utils/social-sharing",
"vendor/fancyfields",
"utils/jquery-ext",
"utils/sticky",
"utils/notification-broker"
],
callback: function (dependencies, jQuery, res, ComponentMgr, PageContext, Analytics, forms, Application, CertonaRecommendations, Modernizr, socialSharing) {
app.firstDomReady.then(function () {
jQuery(".fancyform[name!='sortingForm'][name!='addProductForm']").fancyfields();
jQuery('input[type="checkbox"]')
.fancyfields("bind", "onCheckboxChange", function(input, isChecked) {
jQuery(input).change();
});
jQuery('input[type="radio"]')
.fancyfields("bind", "onRadioChange", function(input) {
jQuery(input).find("radio").prop('checked', false);
jQuery(input).find("radio[value='"+input.val()+"']").prop('checked', true);
jQuery(input).click();
});
jQuery('select')
.fancyfields("bind", "onSelectChange", function(input,text,val) {
jQuery(input).find("option").removeAttr("selected");
jQuery(input).find("option[value='"+val+"']").attr("selected","selected");
});
ComponentMgr.selectorToComponent({
'.showdialog': 'mobile/common/ShowDialog',
'.showpopup': 'common/Popup',
'.showtooltip': 'common/Popover',
'.collapsible': 'common/Collapsible',
'.dataswitch': 'common/Dataswitch',
'.tooltip': 'common/Tooltip'

});
ComponentMgr.setRequiredComponents([
]);
ComponentMgr.setDependencies(dependencies, "checkout");
ComponentMgr.initComponents();
});
// this is a hack
Application.onLoad(function () {
jQuery('#frameContainer').css('visibility', 'visible');
});
}
});

}));
</script><script type="text/javascript" async="" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/adidas-build-COMMON.js"></script><script type="text/javascript" async="" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/adidas-build-checkout.js"></script>



<script type="text/javascript">//<!--
/* <![CDATA[ (head-active_data.js) */
var dw = (window.dw || {});
dw.ac = {
    _analytics: null,
    _events: [],
    _category: "",
    _capture: function(configs) {
        if (Object.prototype.toString.call(configs) === "[object Array]") {
            configs.forEach(captureObject);
            return;
        }
        dw.ac._events.push(configs);
    },
	capture: function() { 
		dw.ac._capture(arguments);
		// send to CQ as well:
		if (window.CQuotient) {
			window.CQuotient.trackEventsFromAC(arguments);
		}
	},
    EV_PRD_SEARCHHIT: "searchhit",
    EV_PRD_DETAIL: "detail",
    EV_PRD_RECOMMENDATION: "recommendation",
    EV_PRD_SETPRODUCT: "setproduct",
    applyContext: function(context) {
        if (typeof context === "object" && context.hasOwnProperty("category")) {
        	dw.ac._category = context.category;
        }
    },
    setDWAnalytics: function(analytics) {
        dw.ac._analytics = analytics;
    }
};
/* ]]> */
// -->
</script><script type="text/javascript">//<!--
/* <![CDATA[ (head-cquotient.js) */
var CQuotient = window.CQuotient = {};
CQuotient.clientId = 'aaqx-adidas-BR';
CQuotient.realm = 'aaqx';
CQuotient.siteId = 'adidas-BR';
CQuotient.instanceType = 'prd';
CQuotient.activities = [];
CQuotient.cqcid='';
CQuotient.cquid='';
CQuotient.initFromCookies = function () {
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
	  var c = ca[i];
	  while (c.charAt(0)==' ') c = c.substring(1,c.length);
	  if (c.indexOf('cqcid=') == 0) {
		  CQuotient.cqcid=c.substring('cqcid='.length,c.length);
	  } else if (c.indexOf('cquid=') == 0) {
		  CQuotient.cquid=c.substring('cquid='.length,c.length);
		  break;
	  }
	}
}
CQuotient.getCQCookieId = function () {
	if(window.CQuotient.cqcid == '')
		window.CQuotient.initFromCookies();
	return window.CQuotient.cqcid;
};
CQuotient.getCQUserId = function () {
	if(window.CQuotient.cquid == '')
		window.CQuotient.initFromCookies();
	return window.CQuotient.cquid;
};
CQuotient.trackEventsFromAC = function (/* Object or Array */ events) {
try {
	if (Object.prototype.toString.call(events) === "[object Array]") {
		events.forEach(_trackASingleCQEvent);
	} else {
		CQuotient._trackASingleCQEvent(events);
	}
} catch(err) {}
};
CQuotient._trackASingleCQEvent = function ( /* Object */ event) {
	if (event && event.id) {
		if (event.type === dw.ac.EV_PRD_DETAIL) {
			CQuotient.trackViewProduct( {id:'', alt_id: event.id, type: 'raw_sku'} );
		} // not handling the other dw.ac.* events currently
	}
};
CQuotient.trackViewProduct = function(/* Object */ cqParamData){
	var cq_params = {};
	cq_params.cookieId = CQuotient.getCQCookieId();
	cq_params.userId = CQuotient.getCQUserId();
	cq_params.product = cqParamData.product;
	cq_params.realm = cqParamData.realm;
	cq_params.siteId = cqParamData.siteId;
	cq_params.instanceType = cqParamData.instanceType;
	
	if(CQuotient.sendActivity) {
		CQuotient.sendActivity(CQuotient.clientId, 'viewProduct', cq_params);
	} else {
		CQuotient.activities.push({activityType: 'viewProduct', parameters: cq_params});
	}
};
/* ]]> */
// -->
</script>










	
	
	
	
	
	
		
			<script type="text/javascript" src="https://tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.sync.js"></script>
		
	





	
	
	
	
	
	
		
	




	
	
	
	
	
	
		
	





	
	








  <script>(window.BOOMR_mq=window.BOOMR_mq||[]).push(["addVar",{"rua.upush":"false","rua.cpush":"false","rua.upre":"false","rua.cpre":"false","rua.uprl":"false","rua.cprl":"false","rua.cprf":"false","rua.trans":"SJ-b53ad875-905b-484e-9e6e-b49f3481d76b","rua.cook":"true","rua.ims":"false","rua.ufprl":"false","rua.cfprl":"true"}]);</script>
  <script>!function(){function o(n,i){if(n&&i)for(var r in i)i.hasOwnProperty(r)&&(void 0===n[r]?n[r]=i[r]:n[r].constructor===Object&&i[r].constructor===Object?o(n[r],i[r]):n[r]=i[r])}try{var n=decodeURIComponent("");if(n.length>0&&window.JSON&&"function"==typeof window.JSON.parse){var i=JSON.parse(n);void 0!==window.BOOMR_config?o(window.BOOMR_config,i):window.BOOMR_config=i}}catch(r){window.console&&"function"==typeof window.console.error&&console.error("mPulse: Could not parse configuration",r)}}();</script>
  <script>!function(e){var a="https://s.go-mpulse.net/boomerang/",t="addEventListener";if("False"=="True")e.BOOMR_config=e.BOOMR_config||{},e.BOOMR_config.PageParams=e.BOOMR_config.PageParams||{},e.BOOMR_config.PageParams.pci=!0,a="https://s2.go-mpulse.net/boomerang/";if(window.BOOMR_API_key="D57Y2-BGVZZ-HBUZB-K9MP7-4DUUC",function(){function n(a){e.BOOMR_onload=a&&a.timeStamp||(new Date).getTime()}if(!e.BOOMR||!e.BOOMR.version&&!e.BOOMR.snippetExecuted){e.BOOMR=e.BOOMR||{},e.BOOMR.snippetExecuted=!0;var i,o,r,_=document.createElement("iframe");if(e[t])e[t]("load",n,!1);else if(e.attachEvent)e.attachEvent("onload",n);_.src="javascript:void(0)",_.title="",_.role="presentation",(_.frameElement||_).style.cssText="width:0;height:0;border:0;display:none;",r=document.getElementsByTagName("script")[0],r.parentNode.insertBefore(_,r);try{o=_.contentWindow.document}catch(O){i=document.domain,_.src="javascript:var d=document.open();d.domain='"+i+"';void(0);",o=_.contentWindow.document}o.open()._l=function(){var e=this.createElement("script");if(i)this.domain=i;e.id="boomr-if-as",e.src=a+"D57Y2-BGVZZ-HBUZB-K9MP7-4DUUC",BOOMR_lstart=(new Date).getTime(),this.body.appendChild(e)},o.write("<bo"+'dy onload="document._l();">'),o.close()}}(),"".length>0)if(e&&"performance"in e&&e.performance&&"function"==typeof e.performance.setResourceTimingBufferSize)e.performance.setResourceTimingBufferSize();!function(){if(BOOMR=e.BOOMR||{},BOOMR.plugins=BOOMR.plugins||{},!BOOMR.plugins.AK){var a="true"=="true"?1:0,t="cookiepresent",n="zcc5uwixbi5kuxpbxcla-f-6895f6722-clientnsv4-s.akamaihd.net",i={"ak.v":25,"ak.cp":"605463","ak.ai":parseInt("238272",10),"ak.ol":"0","ak.cr":29,"ak.ipv":4,"ak.proto":"h2","ak.rid":"246eee8","ak.r":31597,"ak.a2":a,"ak.m":"a","ak.n":"essl","ak.bpcip":"200.133.218.0","ak.cport":1766,"ak.gh":"186.192.152.38","ak.quicv":"","ak.tlsv":"tls1.2","ak.0rtt":"","ak.csrc":"-","ak.acc":"","ak.t":"1575073942"};if(""!==t)i["ak.ruds"]=t;var o={i:!1,av:function(a){var t="http.initiator";if(a&&(!a[t]||"spa_hard"===a[t]))i["ak.feo"]=void 0!==e.aFeoApplied?1:0,BOOMR.addVar(i)},rv:function(){var e=["ak.bpcip","ak.cport","ak.cr","ak.csrc","ak.gh","ak.ipv","ak.m","ak.n","ak.ol","ak.proto","ak.quicv","ak.tlsv","ak.0rtt","ak.r","ak.acc","ak.t"];BOOMR.removeVar(e)}};BOOMR.plugins.AK={akVars:i,akDNSPreFetchDomain:n,init:function(){if(!o.i){var e=BOOMR.subscribe;e("before_beacon",o.av,null,null),e("onbeacon",o.rv,null,null),o.i=!0}return this},is_complete:function(){return!0}}}}()}(window);</script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="utils/sticky" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/utils/sticky.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="vendor/jquery.waypoints" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/jquery.waypoints.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="utils/credit-card" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/utils/credit-card.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="vendor/adyen.encrypt.min" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/adyen.encrypt.min.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="vendor/mailcheck" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/mailcheck.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="vendor/svsgiftcards" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/svsgiftcards.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="vendor/jquery.webui-popover" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/vendor/jquery.webui-popover.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="component/mobile/common/ShowDialog" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/component/mobile/common/ShowDialog.js"></script><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="utils/installements" src="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/utils/installements.js"></script><link data-build="include" type="text/css" rel="stylesheet" href="https://www.adidas.com.br/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/js/component/../../css/pdp.css"><script type="text/javascript" charset="utf-8" async="" data-requirecontext="_" data-requiremodule="https://tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.js" src="https://tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.js"></script><script src="chrome-extension://mooikfkahbdckldjjndioackbalphokd/assets/prompt.js"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_56" src="//tags.tiqcdn.com/utag/tiqapp/utag.currency.js?utv=ut4.46.201911141418"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_349" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.349.js?utv=ut4.46.201907300556"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_89" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.89.js?utv=ut4.46.201911121403"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_305" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.305.js?utv=ut4.46.201910291402"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_4" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.4.js?utv=ut4.46.201905281044"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_247" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.247.js?utv=ut4.46.201910291402"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_176" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.176.js?utv=ut4.46.201909171049"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_394" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.394.js?utv=ut4.46.201908210931"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_233" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.233.js?utv=ut4.46.201909171049"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_358" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.358.js?utv=ut4.46.201911141415"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_395" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.395.js?utv=ut4.46.201903141302"></script><script type="text/javascript" async="" charset="utf-8" id="utag_adidas.adidasglobal_447" src="//tags.tiqcdn.com/utag/adidas/adidasglobal/prod/utag.447.js?utv=ut4.46.201911141415"></script><script type="text/javascript" src="https://f.monetate.net/trk/4/s/a-24f48522/p/adidas.br/1515059286-0?mr=t1507302174&amp;mi='5.1320040346.1575071584785'&amp;mt=!n&amp;cs=!t&amp;e=!(viewPage,gt,gr)&amp;pt=CHECKOUT&amp;r='https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-Start'&amp;sw=1920&amp;sh=1080&amp;sc=24&amp;j=!f&amp;u='https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COSummary2-Start'&amp;fl=!f&amp;hvc=!t&amp;eoq=!t" charset="utf-8" async=""></script><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=pageView&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=conversion&amp;conversion_type=&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=timeSpent&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=timeSpent&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=timeSpent&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=timeSpent&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"><img width="0" height="0" alt="" src="https://t.teads.tv/track?action=timeSpent&amp;advertiser_id=10786&amp;referer=https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start" style="position: absolute;"></head>
<body class="adidas-BR" data-is-inited="true">
<div id="container" class="pt_checkout style-refresh">

	





	
	
	
	
	
	
		
	




	
	
	
	
	
	
		
	




	
	
	
	
	
	
		
	












	

<div class="js-decorate co-checkoutprogressindicator style-refresh">






<div class="wrapper rbk_wrapper">

<ul>
<li class="inactive rbk-visited step-1 layer _3">

<a href="https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/CODelivery-Start?editable=true" title="Detalhes do pedido"><span>1</span>Detalhes do pedido</a>

</li>
<li class="active step-2 layer _3">
<span>2</span>Conferir e pagar
</li>

</ul>
</div>
</div><!-- END: checkoutprogressindicator -->





<div id="main">
<div class="rbk_content_wrapper clearfix">
<div id="content">








<!-- Check for empty name of checkout step -->


    


	









<!-- Check for empty name of checkout step -->


    


	







	
	
	
	
		
	
	
	
		
	




	
	
	
	
	
	
		
	







<div class="checkout-payment  clearfix">



    





























<div class="payment-section col-8" data-ci-test-id="paymentMethod">
	
	
	<div id="cart-top-slot" class="small-callout-container">
		
	 

	
	</div>
	<div class="payment-header checkout-title clearfix">
		<h2>Método de pagamento</h2>
		<div class="securepayment"><span class="icon-svg24"></span>Todas as transações são seguras</div>
	</div>

	


<div class="co-checkoutpayment paymentmethodform paymentinformation ">
	<div class="paymentmethod-list" data-component="payment/Payment">
		
			
				
				
				
				
				
				
					
					
						<div class="payment-method selected" data-selected-payment-method="true" data-payment-allowfreedelivery="false" data-recalculation-required="false" data-ci-test-id="creditcardBlock" style="">
							


	
	
	
	
	
	
		
	






<input type="hidden" id="fingerprint" value="ryEGX8eZpJ0030000000000000LReqQIlGJQ0050271576cVB94iKzBGCsH5JA35az5S16Goh5Mk004wSDfkaZ2NL00000qZkTE00000k65QSeeADamXi4XbIsfy:40">
	<script type="text/javascript" src="https://live.adyen.com/hpp/js/df.js?v=20191130"></script>
	<script>
		dfDo("fingerprint");
	</script>

<div class="adyen_creditcard paymentmethod">
	<div class="payment-method-select clearfix fancyform">
		
			<div class="ffRadioWrapper on"><div class="ffRadio" tabindex="0"></div><span>
			<p><span class="title-22">CARTÃO DE CRÉDITO</span></p>

<div class="payment-logo"><img alt="Credit Card" src="https://www.adidas.com.br/on/demandware.static/-/Sites-adidas-BR-Library/pt_BR/dw33b47322/logos/logos-carta-credito-BR.jpg" title=""></div>

<p>&nbsp;</p>
		</span><input type="radio" name="dwfrm_delivery_billing_paymentMethods_selectedPaymentMethodID" value="CREDIT_CARD" id="creditcard" style="display: none;" checked="checked"></div>
		
		<label for="creditcard" class="label-off">
			<p><span class="title-22">CARTÃO DE CRÉDITO</span></p>

<div class="payment-logo"><img alt="Credit Card" src="https://www.adidas.com.br/on/demandware.static/-/Sites-adidas-BR-Library/pt_BR/dw33b47322/logos/logos-carta-credito-BR.jpg" title=""></div>

<p>&nbsp;</p>
		</label>
	</div>
	<div class="payment-details card-details clearfix" data-component="payment/AdyenPayment" data-allowedcard="visa,mc,dineromail,safetypay,amex,hipercard,elo,maestro,electron,diners">
		
		
		    <div class="form-row formfield installments nobr fancyform fancy-initialised">
				
		        	

 	
 	
	
	

		
			
			
			<label for="dwfrm_adyenencrypted_installments" class="">
				Parcelas
				
					<span> * </span>
				
			</label>
			
		
		
		
			
			<div class="value value-select">
				
				
				
					

					<div class="ffSelectWrapper"><div class="ffSelect" style="z-index: 10; position: relative;"><a href="javascript:void(0)" class="ffSelectButton" style="height: 40px;"><span><i class="selectoption" style="float: left;"></i>1 x R$ 319,99</span></a><div class="ffSelectMenuWrapper" style="position: absolute; top: 40px; overflow: hidden; display: none;"><div class="ffSelectMenuTop"><span></span></div><div class="ffSelectMenuMidBG"><div class="ffSelectMenuMid" style="overflow: auto;"><ul data-cts="500" data-ds="false"><li class="selectoption selected on"><span data-val="1.0">1 x R$ 319,99</span></li><li class="selectoption"><span data-val="2.0">2 x R$ 160,00</span></li><li class="selectoption"><span data-val="3.0">3 x R$ 106,67</span></li><li class="selectoption"><span data-val="4.0">4 x R$ 80,00</span></li><li class="selectoption"><span data-val="5.0">5 x R$ 64,00</span></li><li class="selectoption"><span data-val="6.0">6 x R$ 53,34</span></li><li class="selectoption"><span data-val="7.0">7 x R$ 45,72</span></li></ul></div></div><div class="ffSelectMenuBottom"><span></span></div></div></div><select class="selectbox required" id="dwfrm_adyenencrypted_installments" data-missing-error="Por favor, especifique o valor" data-parse-error="Valor inválido" data-range-error="Value too long or too short" required="required" style="display: none;">
 
					
						
						
							<option class="selectoption" label="1 x R$ 319,99" value="1.0">1 x R$ 319,99</option>
						
					
						
						
							<option class="selectoption" label="2 x R$ 160,00" value="2.0">2 x R$ 160,00</option>
						
					
						
						
							<option class="selectoption" label="3 x R$ 106,67" value="3.0">3 x R$ 106,67</option>
						
					
						
						
							<option class="selectoption" label="4 x R$ 80,00" value="4.0">4 x R$ 80,00</option>
						
					
						
						
							<option class="selectoption" label="5 x R$ 64,00" value="5.0">5 x R$ 64,00</option>
						
					
						
						
							<option class="selectoption" label="6 x R$ 53,34" value="6.0">6 x R$ 53,34</option>
						
					
						
						
							<option class="selectoption" label="7 x R$ 45,72" value="7.0">7 x R$ 45,72</option>
						
					
					</select></div>
					
				
				
				
				    
					   <!-- this MUST be immediately after the input/field tag. Hiden data to be attached to the input field (app.hiddenData in app.js -->
					
				
				
				
			</div>
		
		
		
		
               <span class="errormessage" style="display: none;"></span>
		
	    
		
		
		
		
		
		
		

	
	






		        
		    </div>
		
		
			






<form method="POST" data-component="form/Form" action="https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COPayment-HandlePaymentForm" id="adyen-encrypted-form" novalidate="novalidate" class="validate suppress clearfix">
	<input type="hidden" name="selectedPaymentMethodID" value="CREDIT_CARD" checked="checked">
	<input type="hidden" value="2019-11-30T00:32:22.945Z" data-encrypted-name="generationtime" id="adyen-encrypted-form-expiry-generationtime">
	<input type="hidden" value="" data-encrypted-name="expiryMonth" id="adyen-encrypted-form-expiry-month">
	<input type="hidden" value="" data-encrypted-name="expiryYear" id="adyen-encrypted-form-expiry-year">
	<input type="hidden" name="installments" value="1" id="installments">
	<input type="hidden" name="fingerprint" value="">
	<input type="hidden" name="creditCardType" value="">
	<div class="hide" id="cse-key"> 
		10001|C1B003094C0E0F486D1C88A69756064B3F91F064D908703698357B58FEA57B301C7 66E73246B9228F4D2ED1B70ABFE3B69DD0592239A90345E450EF95FF6A9B70A7AF2765D33 6A310F1A293C4DA00ADCC959CD17EA9E93C71FB4DA1655BF99D23CC26FE832A7B61BE9DE 3E7E3217D956FFC0565F0B9C4695D73E648F35CFC9853F1EF2AA6A235C6FB2C95BB1B10F0E CC571FE7764ACAFE2002041F0C9B74DE3C375E0FDD6B02B59EC71E7AB2E7242E747A7F804 8CDB57120103A7532BF127676BF592804F286DC01C2E79E8CEA44A188F3D4D012774271C7 55BDC6FD4E5C6D4C59752A2923DA5F9A94E05ABA40CAD65AFDE331481140C4FDE2B314E9 2FFA3F17
	</div>
	<fieldset>
		
		
		<div class="form-row formfield number clearfix">
			

 	
 	
	
	

		
			
			<div class="labelwithcaption">
			<label for="dwfrm_adyenencrypted_number" class="">
				Número do cartão
				
					<span> * </span>
				
			</label>
			
		
		
		
			
			<div class="value">
				
				
				
					
				 	
				 	 <input class="textinput required" id="dwfrm_adyenencrypted_number" type="tel" value="" maxlength="25" data-encrypted-name="number" data-ci-test-id="cardNumberField" data-missing-error="Please enter the Number as it appears on your card" data-parse-error="Número de cartão inválido" data-range-error="Value too long or too short" data-value-error="Número de cartão inválido" required="required" autocorrect="off">
				<!-- display text area input field -->
				
				
				    
					   <!-- this MUST be immediately after the input/field tag. Hiden data to be attached to the input field (app.hiddenData in app.js -->
					
				
				
				
			</div>
		
		
		
		
               <span class="errormessage" style="display: none;"></span>
		
	    
		
			
			
			<div class="caption ">
				<span>(sem espaço)</span>
			</div>
			</div>
		
		
		
		
		
		
		

	
	






		</div>
		<div class="form-row formfield owner clearfix">
			

 	
 	
	
	

		
			
			
			<label for="dwfrm_adyenencrypted_holderName" class="">
				Nome do titular do cartão 
				
					<span> * </span>
				
			</label>
			
		
		
		
			
			<div class="value valid on">
				
				
				
					
				 	
				 	 <input class="textinput required" id="dwfrm_adyenencrypted_holderName" type="text" value="Gustavo Mota" maxlength="2147483647" data-encrypted-name="holderName" data-ci-test-id="nameOnCardField" data-missing-error="Please enter your Name as it appears on the card" data-parse-error="Please enter your Name as it appears on the card" data-range-error="Please enter your Name as it appears on the card" pattern="^[^0-9`!@#$%\^&amp;\*\(\)=\+\[\]\\\{\}:;?\/<>]{4,40}$" required="required">
				<!-- display text area input field -->
				
				
				    
					   <!-- this MUST be immediately after the input/field tag. Hiden data to be attached to the input field (app.hiddenData in app.js -->
					
				
				
				
			</div>
		
		
		
		
               <span class="errormessage" style="display: none;"></span>
		
	    
		
		
		
		
		
		
		

	
	






		</div>
		<div class="form-row exp-date clearfix fancyform fancy-initialised">
			<div class="formfield expired-label monthcaption">
				<label>Expira <span class="mandatory">*</span></label>
			</div>
			<div class="formfield month" data-ci-test-id="monthDropdown">
				

 	
 	
	
	

		
		
		
			
			<div class="value value-select">
				
				
				
					

					<div class="ffSelectWrapper"><div class="ffSelect" style="z-index: 10; position: relative;"><a href="javascript:void(0)" class="ffSelectButton" style="height: 40px;"><span><i class="selectoption" style="float: left;"></i>Mês</span></a><div class="ffSelectMenuWrapper" style="position: absolute; display: none; top: 40px;"><div class="ffSelectMenuTop"><span></span></div><div class="ffSelectMenuMidBG"><div class="ffSelectMenuMid" style="overflow: auto;"><ul data-cts="500" data-ds="false"><li class="selectoption on selected"><span data-val="">Mês</span></li><li class="selectoption"><span data-val="01">01</span></li><li class="selectoption"><span data-val="02">02</span></li><li class="selectoption"><span data-val="03">03</span></li><li class="selectoption"><span data-val="04">04</span></li><li class="selectoption"><span data-val="05">05</span></li><li class="selectoption"><span data-val="06">06</span></li><li class="selectoption"><span data-val="07">07</span></li><li class="selectoption"><span data-val="08">08</span></li><li class="selectoption"><span data-val="09">09</span></li><li class="selectoption"><span data-val="10">10</span></li><li class="selectoption"><span data-val="11">11</span></li><li class="selectoption"><span data-val="12">12</span></li></ul></div></div><div class="ffSelectMenuBottom"><span></span></div></div></div><select class="selectbox required" id="dwfrm_adyenencrypted_expiryMonth" data-missing-error="Please select an Expiration Month" data-parse-error="Valor inválido" data-range-error="Value too long or too short" data-value-error="Expiry date is invalid" pattern="^(:?0[1-9]|1[0-2])$" required="required" style="display: none;">
 
					
						
						
							<option class="selectoption" label="Mês" value="">Mês</option>
						
					
						
						
							<option class="selectoption" label="01" value="01">01</option>
						
					
						
						
							<option class="selectoption" label="02" value="02">02</option>
						
					
						
						
							<option class="selectoption" label="03" value="03">03</option>
						
					
						
						
							<option class="selectoption" label="04" value="04">04</option>
						
					
						
						
							<option class="selectoption" label="05" value="05">05</option>
						
					
						
						
							<option class="selectoption" label="06" value="06">06</option>
						
					
						
						
							<option class="selectoption" label="07" value="07">07</option>
						
					
						
						
							<option class="selectoption" label="08" value="08">08</option>
						
					
						
						
							<option class="selectoption" label="09" value="09">09</option>
						
					
						
						
							<option class="selectoption" label="10" value="10">10</option>
						
					
						
						
							<option class="selectoption" label="11" value="11">11</option>
						
					
						
						
							<option class="selectoption" label="12" value="12">12</option>
						
					
					</select></div>
					
				
				
				
				
				
			</div>
		
		
		
		
               <span class="errormessage" style="display: none;"></span>
		
	    
		
		
		
		
		
		
		

	
	






			</div>
			<div class="formfield year nobr" data-ci-test-id="yearDropdown">
				

 	
 	
	
	

		
		
		
			
			<div class="value value-select">
				
				
				
					

					<div class="ffSelectWrapper"><div class="ffSelect" style="z-index: 10; position: relative;"><a href="javascript:void(0)" class="ffSelectButton" style="height: 40px;"><span><i class="selectoption" style="float: left;"></i>Ano</span></a><div class="ffSelectMenuWrapper" style="position: absolute; display: none; top: 40px;"><div class="ffSelectMenuTop"><span></span></div><div class="ffSelectMenuMidBG"><div class="ffSelectMenuMid" style="overflow: auto;"><ul data-cts="500" data-ds="false"><li class="selectoption on selected"><span data-val="">Ano</span></li><li class="selectoption"><span data-val="2019">2019</span></li><li class="selectoption"><span data-val="2020">2020</span></li><li class="selectoption"><span data-val="2021">2021</span></li><li class="selectoption"><span data-val="2022">2022</span></li><li class="selectoption"><span data-val="2023">2023</span></li><li class="selectoption"><span data-val="2024">2024</span></li><li class="selectoption"><span data-val="2025">2025</span></li><li class="selectoption"><span data-val="2026">2026</span></li><li class="selectoption"><span data-val="2027">2027</span></li><li class="selectoption"><span data-val="2028">2028</span></li><li class="selectoption"><span data-val="2029">2029</span></li><li class="selectoption"><span data-val="2030">2030</span></li><li class="selectoption"><span data-val="2031">2031</span></li><li class="selectoption"><span data-val="2032">2032</span></li><li class="selectoption"><span data-val="2033">2033</span></li><li class="selectoption"><span data-val="2034">2034</span></li><li class="selectoption"><span data-val="2035">2035</span></li><li class="selectoption"><span data-val="2036">2036</span></li><li class="selectoption"><span data-val="2037">2037</span></li><li class="selectoption"><span data-val="2038">2038</span></li><li class="selectoption"><span data-val="2039">2039</span></li></ul></div></div><div class="ffSelectMenuBottom"><span></span></div></div></div><select class="selectbox required" id="dwfrm_adyenencrypted_expiryYear" data-missing-error="Please select an Expiration Year" data-parse-error="Valor inválido" data-range-error="Value too long or too short" required="required" style="display: none;">
 
					
						
						
							<option class="selectoption" label="Ano" value="">Ano</option>
						
					
						
						
							<option class="selectoption" label="2019" value="2019">2019</option>
						
					
						
						
							<option class="selectoption" label="2020" value="2020">2020</option>
						
					
						
						
							<option class="selectoption" label="2021" value="2021">2021</option>
						
					
						
						
							<option class="selectoption" label="2022" value="2022">2022</option>
						
					
						
						
							<option class="selectoption" label="2023" value="2023">2023</option>
						
					
						
						
							<option class="selectoption" label="2024" value="2024">2024</option>
						
					
						
						
							<option class="selectoption" label="2025" value="2025">2025</option>
						
					
						
						
							<option class="selectoption" label="2026" value="2026">2026</option>
						
					
						
						
							<option class="selectoption" label="2027" value="2027">2027</option>
						
					
						
						
							<option class="selectoption" label="2028" value="2028">2028</option>
						
					
						
						
							<option class="selectoption" label="2029" value="2029">2029</option>
						
					
						
						
							<option class="selectoption" label="2030" value="2030">2030</option>
						
					
						
						
							<option class="selectoption" label="2031" value="2031">2031</option>
						
					
						
						
							<option class="selectoption" label="2032" value="2032">2032</option>
						
					
						
						
							<option class="selectoption" label="2033" value="2033">2033</option>
						
					
						
						
							<option class="selectoption" label="2034" value="2034">2034</option>
						
					
						
						
							<option class="selectoption" label="2035" value="2035">2035</option>
						
					
						
						
							<option class="selectoption" label="2036" value="2036">2036</option>
						
					
						
						
							<option class="selectoption" label="2037" value="2037">2037</option>
						
					
						
						
							<option class="selectoption" label="2038" value="2038">2038</option>
						
					
						
						
							<option class="selectoption" label="2039" value="2039">2039</option>
						
					
					</select></div>
					
				
				
				
				
				
			</div>
		
		
		
		
               <span class="errormessage" style="display: none;"></span>
		
	    
		
		
		
		
		
		
		

	
	






			</div>
		</div>
		<div class="form-row formfield cvv clearfix" tabindex="0">
			

 	
 	
	
	

		
			
			
			<label for="dwfrm_adyenencrypted_cvc" class="">
				CVV
				
					<span> * </span>
				
			</label>
			
		
		
		
			
			<div class="value">
				
				
				
					
				 	
				 	 <input class="textinput required" id="dwfrm_adyenencrypted_cvc" type="tel" value="" maxlength="2147483647" data-encrypted-name="cvc" autocomplete="off" data-ci-test-id="CVVField" data-missing-error="Please enter your Security Code" data-parse-error="Invalid CVV" data-range-error="Value too long or too short" pattern="^[0-9]{3,4}$" required="required" autocorrect="off">
				<!-- display text area input field -->
				
				
				    
					   <!-- this MUST be immediately after the input/field tag. Hiden data to be attached to the input field (app.hiddenData in app.js -->
					
				
				
				
			</div>
		
		
		
		
               <span class="errormessage" style="display: none;"></span>
		
	    
		
		
		
		
		
		
		

	
	






			<div class="tips_container cvn_code floated-popup" tabindex="0">
				
					<a class="showtooltip" data-placement="right" data-width="340" data-title="Código de segurança" data-component="common/Popover"></a><div class="tooltip-body">











<div class="contentasset" data-contentasset-id="cvn-code" data-contentasset="cvn-code">
O código de segurança são os três últimos números encontrados na parte de trás do cartão.
</div><!-- End contentasset -->



</div>
				
			</div>
		</div>
		
		
		
			
		<input type="submit" value="Submit" class="excluded-from-render hidden displayNone">
	</fieldset>
</form>


		
		<div class="payment-submit clearfix">
			<p><button class="co-btn_primary btn_showcart button-full-width button-ctn button-brd adi-gradient-blue button-forward" style="width:280px;" type="submit"><span>FINALIZAR COMPRA</span></button></p>

<div class="termsconditions clear-left">
<div class="deliverytermsmessage">Todas as transações são seguras. Em caso de dúvidas, por favor consulte <a _dialogtitle="Política de privacidad" class="showpopup" href="http://www.adidas.com.br/help-topics-terms_and_conditions.html" target="_blank" data-component="common/Popup">TERMOS DE USO E CONDIÇÕES DE NAVEGAÇÃO</a></div>
</div>
		</div>
		
	</div>
</div>
						</div>
					
				
			
				
				
				
				
				
				
					
					
						<div class="payment-method collapsed" data-selected-payment-method="false" data-payment-allowfreedelivery="false" data-recalculation-required="true" data-ci-test-id="boletobancarioBlock" style="">
							
<div class="adyen-offline">
	<div class="payment-method-select fancyform clearfix" data-component="form/Form">
		<div class="ffRadioWrapper"><div class="ffRadio" tabindex="0"></div><span>
			<div class="payment-title">
<span class="title-22">BOLETO BANCARIO</span>
<div class="payment-subheadline">via boleto bancário</div>
</div>

<div class="payment-logo"><img alt="boleto_bancario" src="https://www.adidas.com.br/on/demandware.static/-/Sites/pt_BR/dw936892bb/boleto_bancario_logo.png"></div>
		</span><input type="radio" name="dwfrm_delivery_billing_paymentMethods_selectedPaymentMethodID" value="BoletoBancario" id="dwfrm_delivery_billing_paymentMethods_selectedPaymentMethodID" style="display: none;"></div>
		<label for="dwfrm_delivery_billing_paymentMethods_selectedPaymentMethodID" class="label-off">
			<div class="payment-title">
<span class="title-22">BOLETO BANCARIO</span>
<div class="payment-subheadline">via boleto bancário</div>
</div>

<div class="payment-logo"><img alt="boleto_bancario" src="https://www.adidas.com.br/on/demandware.static/-/Sites/pt_BR/dw936892bb/boleto_bancario_logo.png"></div>
		</label>
	</div>
	<form data-component="form/Form" action="https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/COPayment-HandlePaymentForm" method="post" id="dwfrm_delivery_billing_paymentMethods" data-cm-place-fire-start="true" class="fancyform validate suppress clearfix selected" novalidate="novalidate" autocomplete="on">
		<input type="hidden" name="selectedPaymentMethodID" value="BoletoBancario">
		<input type="hidden" name="fingerprint" value="">
		<div class="payment-details clearfix">
			<div class="boleto_bancario_description">
<ul>
	<li>Imprima o Boleto Bancário após a confirmação do pedido.</li>
	<li>A data de vencimento é de 3&nbsp;dias corridos após o fechamento do pedido. Após esta data, ele será automaticamente cancelado.</li>
	<li>Para pagar o Boleto pelo Internet Banking de seu banco, digite o código de barras.</li>
	<li>Não é possível pagar o seu pedido através de DOC, transferência ou depósito para conta indicada neste boleto.</li>
	<li>Atenção: desative seu programa anti pop-up caso esteja ativado para que consiga finalizar sua compra com esta forma de pagamento.</li>
	<li>O banco enviará a confirmação do pagamento em até 4&nbsp;dias úteis. Após essa confirmação o pedido é liberado para entrega, conforme nossa <a _dialogtitle=" " class="showpopup" href="https://www.adidas.com.br/help-topics-shipping.html" target="_blank" data-component="common/Popup">política de entrega</a>.</li>
</ul>
</div>
			<div class="payment-submit">
				<p><button class="co-btn_primary btn_showcart button-full-width button-ctn button-brd adi-gradient-blue button-forward" style="width:280px;" type="submit"><span>FINALIZAR COMPRA</span></button></p>

<div class="termsconditions clear-left">
<div class="deliverytermsmessage">Todas as transações são seguras. Em caso de dúvidas, por favor consulte <a _dialogtitle="Política de privacidad" class="showpopup" href="http://www.adidas.com.br/help-topics-terms_and_conditions.html" target="_blank" data-component="common/Popup">TERMOS DE USO E CONDIÇÕES DE NAVEGAÇÃO</a></div>
</div>
			</div>
		</div>
	</form>
</div>

						</div>
					
				
			
		
		
		
			




		
	</div>
</div>

	

	

	
	
		<div class="js_consents payment payment-above-btn" data-component="common/LegalConsent" data-page="payment" style="display: none;">
			























































 
		</div>
	
	<div class="outer-payment-submit stylerefresh" data-ci-test-id="paymentSubmitButton"><div class="payment-submit clearfix">
			<p><button class="co-btn_primary btn_showcart button-full-width button-ctn button-brd adi-gradient-blue button-forward" style="width:280px;" type="submit"><span>FINALIZAR COMPRA</span></button></p>

<div class="termsconditions clear-left">
<div class="deliverytermsmessage">Todas as transações são seguras. Em caso de dúvidas, por favor consulte <a _dialogtitle="Política de privacidad" class="showpopup" href="http://www.adidas.com.br/help-topics-terms_and_conditions.html" target="_blank" data-component="common/Popup">TERMOS DE USO E CONDIÇÕES DE NAVEGAÇÃO</a></div>
</div>
		</div></div>

	<div class="paymentprivacypolicy">
		
	</div>
	
	


	
	
</div>

<div class="col-4 co-delivery-right" id="summary-container" data-ci-test-id="reviewNPayOrderSummary">


	




















<script>
if (false) {
app.isMobile = false
}
</script>
























	
	
	
	
	
	
		
	











</div>



<input type="hidden" id="fingerprint">
<script type="text/javascript" src="https://live.adyen.com/hpp/js/df.js?v=20191130"></script>
<script>
//<![CDATA[
dfDo("fingerprint");
//]]>
</script>

</div>

</div><!-- END: content -->
</div><!-- EO: rbk_content_wrapper -->
</div> <!-- END: main -->




<div id="session_timeout_overlay" class="session-timeout-overlay" data-component="checkout/SessionTimeoutOverlay">
<div class="overlay-content cart-wrapper">

	 


	






<h2>Sua sessão expirou<br>
O que isso significa?</h2>
<p>Para a segurança e proteção de seus dados online, uma sessão de navegação expira após 30 minutos de inatividade.</p>
<p>Mas as suas ações não foram perdidas. Salvamos o seu carrinho.</p>


 
	
<div class="returntocart clearfix">
<a class="returntocartbutton gl-cta gl-cta--primary" href="/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-Show" title="Voltar ao carrinho">

Voltar ao carrinho<span class="icon-arrow-right-long icon--size-l gl-cta__icon "></span>

</a>
</div>
</div>
</div>
</div><!-- END: container -->



<div id="checkout_footer" class=" clearfix" data-component="common/footer/Footer">
<div class="wrapper">
<!-- Reebok checkout bottom content -->
<div class="rbk_checkout_bottom">

	 

	
</div>
</div>
<div class="checkout-footer-copy">
<div class="wrapper">

	 


	
<div class="htmlslotcontainer">
	
		
			<div class="copy-wrapper">
<ol class="copy">
    <li><a href="https://www.adidas.com.br/help-topics-privacy_policy.html">Política de Privacidade</a></li>
    <li><a href="https://www.adidas.com.br/help-topics-imprint.html">Imprint</a></li>
    <li>
    <p>© 2016 adidas Brasil</p>
    </li>
</ol>
</div>	
		
	
</div> 
	
</div>
</div>





















































</div>






<script type="text/javascript">













function createCYEvent(ocy){


cy.UserId = "gudamota@gmail.com"




cy.Custom1 = "Gustavo";


cy.CUSTOMERCODE = "1561934516";







//define the base link for SeeWhy to use in the email
var link = "www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/Cart-UpdateItems";
position=1;






cyNewBasketLine();
cyAddBasketLineDetail('ItemName', 'Jaqueta Asymm');
cyAddBasketLineDetail('ItemDesc', 'Estilo cl&aacute;ssico com um toque moderno. Blocos de cores estilo retr&ocirc; criam uma grande estampa de grade na superf&iacute;cie desta jaqueta. Ela &eacute; feita de malha leve e macia com corte quadrado. O contorno do logo Trefoil bordado completa o visual.');
cyAddBasketLineDetail('ItemPageURL', 'www.adidas.com.br/jaqueta-asymm/ED6242_290.html');
cyAddBasketLineDetail('ItemPrice','298.73');
cyAddBasketLineDetail('ItemQuantity','1.0');
cyAddBasketLineDetail('ItemID','ED6242_290');
cyAddBasketLineDetail('ItemImageURL','www.adidas.com.br/dw/image/v2/aaqx_prd/on/demandware.static/Sites-adidas-BR-Site/Sites-adidas-products/pt_BR/v1575016193036/zoom/ED6242_21_model.jpg?sw=110&sh=110&sm=fit');
//Add the line item product ID and quantity to the SeeWhy link
if(position==1) {
link = link + "?pid_" + position + "=ED6242_290&qty_" + position + "=1.0";
} else {
link = link + "&pid_" + position + "=ED6242_290&qty_" + position + "=1.0";
}
position++;




//If there is a coupon attached to the basket, add it to the link. There can be only one coupon assigned to the basket

cy.ReturnToLink = link;



cy.Custom5 = "BRL";
cy.Value = "251.56";




cy.FunnelLevel="4";







_cySetCYProperties(ocy);

cy_getImageSrc();
}//end function createCYEvent
if(!cy.SUPPRESSDEFAULT && true){
createCYEvent();
}
(function(){



var firstName = $('#dwfrm_delivery_singleshipping_shippingAddress_addressFields_firstName');
$('#dwfrm_delivery_singleshipping_shippingAddress_email_emailAddress,#dwfrm_login_email').on('change',function(ev){
var customerName = firstName.val();
var emailField = $(this);
if((emailField.attr('name') == "dwfrm_delivery_singleshipping_shippingAddress_email_emailAddress") && true && !customerName.length){
customerName = "Guest";
}
createCYEvent({ UserId: emailField.val(), Custom1: customerName });
});

})();

</script>
<!-- End SeeWhy setcheckoutvariables Code -->






	
	
	
	
	
	
		
	




	
	
	
	
	
	
		
	




	
	
	
	
	
	
		
	




	
	
	
	
	
	
		
	


<script type="text/json" data-component="analytics/Checkout"></script>





	
	


<!--googleoff: all--><noindex>
	<div class="hidden" data-component="pagecontext/Context">%7B%22ajaxCall%22%3Afalse%2C%22environment%22%3A%22production%22%2C%22production%22%3Atrue%2C%22is_mobile%22%3A%22%22%2C%22date%22%3A%22291119%22%2C%22localeCountry%22%3A%22br%22%2C%22session_id%22%3A%22UzYMXfVXJhAoMRrrycr5Jm1n_FDtu7HuDIE%3D%22%2C%22innerCall%22%3Afalse%2C%22page_type%22%3A%22checkout%22%2C%22page_name%22%3A%22payment%22%2C%22analytics%22%3A%7B%22tags%22%3A%5B%7B%22event%22%3A%22ready%22%2C%22type%22%3A%22pageview%22%2C%22scheme%22%3A%22shipping%22%2C%22attributes%22%3A%7B%22page_type%22%3A%22CHECKOUT%22%2C%22customer_email%22%3A%22%24cookies.customer_email%22%2C%22customer_encrypted_email%22%3A%22%24cookies.customer_encrypted_email%22%2C%22breadcrumb%22%3A%22%22%2C%22customer_payment_type%22%3A%22%22%2C%22payment_error%22%3Anull%2C%22customer_billing_country%22%3A%22BR%22%2C%22product_id**%22%3Anull%2C%22cart_id%22%3A%2274c0b2103ec9ff3ee2d843fc6a%22%2C%22dw_version%22%3A%22%24dw_version%22%2C%22geo_country%22%3A%22%24cookies.geo_country%22%2C%22environment%22%3Anull%2C%22site_name%22%3Anull%2C%22country%22%3Anull%2C%22language%22%3Anull%2C%22is_mobile%22%3Anull%2C%22page_name%22%3Anull%2C%22is_customizable%22%3Anull%2C%22breadcrumb*%22%3A%22%24breadcrumbs%22%2C%22date%22%3Anull%2C%22logged_in%22%3Anull%2C%22customer_id%22%3A%22%24cookies.customer_id%22%2C%22euci%22%3A%22%24cookies.euci%22%2C%22form_name*%22%3Anull%2C%22form_error*%22%3Anull%2C%22form_field_value*%22%3Anull%2C%22dw_test_id%22%3Anull%2C%22dw_segment_id%22%3Anull%2C%22certona_recs_scheme%22%3Anull%2C%22certona_recs_count%22%3Anull%2C%22certona_recs_query%22%3Anull%2C%22session_id%22%3Anull%7D%7D%2C%7B%22event%22%3A%22go-payment%22%2C%22type%22%3A%22link%22%2C%22scheme%22%3A%22go-payment%22%2C%22attributes%22%3A%7B%22event%22%3A%22ELEMENT%22%2C%22event_category%22%3A%22CHECKOUT%7CREVIEW%20AND%20PAY%22%2C%22event_name%22%3A%22%7B0%7D%22%2C%22link_name%22%3Anull%2C%22link_href%22%3Anull%7D%7D%2C%7B%22event%22%3A%22checkout-changecard%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22checkout-changecard%22%2C%22attributes%22%3A%7B%22event_category%22%3A%22CREDIT%20CARD%20TOKENIZATION%22%2C%22event_name%22%3A%22SAVED%20CARD%20%7B0%7D%22%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22go-payment%22%2C%22type%22%3A%22link%22%2C%22scheme%22%3A%22go-payment%22%2C%22attributes%22%3A%7B%22event%22%3A%22ELEMENT%22%2C%22event_category%22%3A%22CHECKOUT%7CREVIEW%20AND%20PAY%22%2C%22event_name%22%3A%22%7B0%7D%22%2C%22link_name%22%3Anull%2C%22link_href%22%3Anull%7D%7D%2C%7B%22event%22%3A%22cart-wishlistadd-ED6242%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22wishlistadd%22%2C%22attributes%22%3A%7B%22event_name%22%3A%22ADD%20TO%20WISHLIST%22%2C%22event_category%22%3A%22%24page_type%22%2C%22product_id*%22%3A%22ED6242%22%2C%22product_model_id*%22%3A%22GDG50%22%2C%22product_name*%22%3A%22Jaqueta%20Asymm%22%2C%22product_price*%22%3A298.74%2C%22product_price_vat*%22%3A379.99%2C%22product_gender*%22%3A%22MEN%22%2C%22product_category*%22%3A%22Clothing%22%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22cart-editproduct-ED6242_290%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22cart-editproduct%22%2C%22attributes%22%3A%7B%22event_name%22%3A%22%7B0%7D%20PRODUCT%22%2C%22event_category%22%3A%22SHOPPING%20CART%22%2C%22product_color*%22%3A%22White%20%2F%20Active%20Teal%20%2F%20Berry%22%2C%22product_colorways*%22%3A%22White%20%2F%20Active%20Teal%20%2F%20Berry%22%2C%22product_group*%22%3A%22inline%22%2C%22product_id*%22%3A%22ED6242%22%2C%22product_model_id*%22%3A%22GDG50%22%2C%22product_name*%22%3A%22Jaqueta%20Asymm%22%2C%22product_personalization*%22%3A%22NO%22%2C%22product_price*%22%3A298.74%2C%22product_price_type*%22%3A%22ON%20SALE%22%2C%22product_price_book*%22%3A%22adidas-BR-listprices%22%2C%22product_price_vat*%22%3A379.99%2C%22product_quantity*%22%3A1%2C%22product_rating*%22%3A0%2C%22product_reviews*%22%3A0%2C%22product_size*%22%3Anull%2C%22product_sizes*%22%3Anull%2C%22product_sku*%22%3A%22ED6242_290%22%2C%22product_status*%22%3A%22IN%20STOCK%22%2C%22product_video*%22%3A%22OFF%22%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22checkout-editaddress%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22checkout-editaddress%22%2C%22attributes%22%3A%7B%22event_name%22%3A%22PAYMENT%3A%20EDIT%20%7B0%7D%20ADDRESS%22%2C%22event_category%22%3A%22CHECKOUT%22%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22orderreview-accordion%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22orderreview-accordion%22%2C%22attributes%22%3A%7B%22event_category%22%3A%22ORDER%20REVIEW%20ACCORDION%22%2C%22current_step%22%3A%22PAYMENT%22%2C%22current_action%22%3A%22EXPAND%22%2C%22event%22%3A%22ELEMENT%22%2C%22event_name%22%3Anull%7D%7D%2C%7B%22event%22%3A%22wishlistadd%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22wishlistadd%22%2C%22attributes%22%3A%7B%22event_name%22%3A%22ADD%20TO%20WISHLIST%22%2C%22event_category%22%3A%22%24page_type%22%2C%22product_id*%22%3A%22ED6242%22%2C%22product_model_id*%22%3A%22GDG50%22%2C%22product_name*%22%3A%22Jaqueta%20Asymm%22%2C%22product_price*%22%3A298.74%2C%22product_price_vat*%22%3A379.99%2C%22product_gender*%22%3A%22MEN%22%2C%22product_category*%22%3A%22Clothing%22%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22wishlistremove%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22wishlistremove%22%2C%22attributes%22%3A%7B%22event_name%22%3A%22REMOVE%20FROM%20WISHLIST%22%2C%22event_category%22%3A%22%24page_type%22%2C%22product_id*%22%3A%22ED6242%22%2C%22product_model_id*%22%3A%22GDG50%22%2C%22product_name*%22%3A%22Jaqueta%20Asymm%22%2C%22product_price*%22%3A298.74%2C%22product_price_vat*%22%3A379.99%2C%22product_gender*%22%3A%22MEN%22%2C%22product_category*%22%3A%22Clothing%22%2C%22product_quantity*%22%3A1%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22form-error%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22form-error%22%2C%22attributes%22%3A%7B%22event_category%22%3A%22FORM%20ERRORS%22%2C%22form_name%22%3A%22%7B0%7D%22%2C%22form_error%22%3A%22%7B1%7D%22%2C%22form_field_value%22%3A%22%7B2%7D%22%2C%22event%22%3A%22ELEMENT%22%2C%22event_name%22%3Anull%7D%7D%2C%7B%22event%22%3A%22navigation-click%22%2C%22type%22%3A%22link%22%2C%22scheme%22%3A%22navigation-click%22%2C%22attributes%22%3A%7B%22event_category%22%3A%22NAVIGATION%20CLICK%22%2C%22link_name%22%3A%22%7B0%7D%22%2C%22link_href%22%3A%22%7B1%7D%22%2C%22event%22%3A%22LINK%22%7D%7D%2C%7B%22event%22%3A%22delivery-changemethod%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22delivery-changemethod%22%2C%22attributes%22%3A%7B%22event_name%22%3A%22DELIVERY%20METHOD%20SELECTED%22%2C%22event_category%22%3A%22CHECKOUT%22%2C%22delivery_method%22%3A%22%7B0%7D%22%2C%22event%22%3A%22ELEMENT%22%7D%7D%2C%7B%22event%22%3A%22checkout-promocode%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22checkout-promocode%22%2C%22attributes%22%3A%7B%22event_category%22%3A%22%7B0%7D%20PROMO%20CODES%22%2C%22promo_code%22%3A%22%7B1%7D%22%2C%22event%22%3A%22ELEMENT%22%2C%22event_name%22%3Anull%7D%7D%2C%7B%22event%22%3A%22generic%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22generic%22%2C%22attributes%22%3A%7B%22event%22%3A%22ELEMENT%22%2C%22event_name%22%3Anull%2C%22event_category%22%3Anull%7D%7D%2C%7B%22event%22%3A%22checkout-gift-cards%22%2C%22type%22%3A%22element%22%2C%22scheme%22%3A%22checkout-gift-cards%22%2C%22attributes%22%3A%7B%22event_category%22%3A%22%7B0%7D%20GIFT%20CARDS%22%2C%22gift_card_number%22%3A%22%7B1%7D%22%2C%22event%22%3A%22ELEMENT%22%2C%22event_name%22%3Anull%7D%7D%2C%7B%22event%22%3A%22session-timeout%22%2C%22type%22%3A%22pageview%22%2C%22scheme%22%3A%22session-timeout%22%2C%22attributes%22%3A%7B%22page_name%22%3A%22SESSION%20TIMEOUT%22%2C%22page_type%22%3A%22CHECKOUT%22%2C%22country%22%3Anull%2C%22language%22%3Anull%2C%22cart_id%22%3A%2274c0b2103ec9ff3ee2d843fc6a%22%7D%7D%5D%2C%22tealium_library%22%3A%22https%3A%2F%2Ftags.tiqcdn.com%2Futag%2Fadidas%2Fadidasglobal%2Fprod%2Futag.js%22%2C%22tealium_sync_library%22%3A%22https%3A%2F%2Ftags.tiqcdn.com%2Futag%2Fadidas%2Fadidasglobal%2Fprod%2Futag.sync.js%22%7D%2C%22config%22%3A%7B%22replace%22%3A%5B%22filters_applied*%22%2C%22product_id%22%2C%22product_sku%22%2C%22product_name%22%2C%22**%22%5D%7D%2C%22site_name%22%3A%22Adidas%22%2C%22country%22%3A%22BR%22%2C%22language%22%3A%22pt%22%2C%22profile%22%3A%22adidasglobal%22%2C%22is_customizable%22%3A%22%22%2C%22logged_in%22%3A%22%22%2C%22product_id**%22%3A%22ED6242%22%2C%22shipping_total%22%3A0%2C%22order_total%22%3A251.56%2C%22product_image_url**%22%3A%22https%3A%2F%2Fassets.adidas.com%2Fimages%2Fw_280%2Ch_280%2Cf_auto%2Cq_auto%3Asensitive%2Fa1551c17f48e43a6b2e2aa3201692dfb_9366%2FED6242_290_21_model.jpg%22%2C%22product_sizes*%22%3A%22P%2CM%2CG%2CGG%22%2C%22product_size*%22%3A%22GG%22%2C%22product_price_vat**%22%3A319.99%2C%22product_price**%22%3A%5B298.73%5D%2C%22order_subtotal%22%3A298.73%2C%22product_prorated_discount**%22%3A0%2C%22product_prorated_vat**%22%3A81.26%2C%22product_campaign_ids*%22%3A%22OUTLET-MARKDOWN-PERMANENT%22%2C%22dw_version%22%3A%222019w47_104%22%2C%22session%22%3A%7B%7D%2C%22_MAX_DEPTH_LEVEL%22%3A3%2C%22_MAX_OBJECT_PROPS%22%3A10%2C%22events%22%3A%5B%5D%7D</div>
</noindex><!--googleon: all-->




    



<script type="text/json" data-component="package/InjectionSlots"></script>





<!-- Demandware Analytics code 1.0 (body_end-analytics-tracking-asynch.js) -->
<script type="text/javascript">//<!--
/* <![CDATA[ */
function trackPage() {
    try{
        var trackingUrl = "https://www.adidas.com.br/on/demandware.store/Sites-adidas-BR-Site/pt_BR/__Analytics-Start";
        var dwAnalytics = dw.__dwAnalytics.getTracker(trackingUrl);
        if (typeof dw.ac == "undefined") {
            dwAnalytics.trackPageView();
        } else {
            dw.ac.setDWAnalytics(dwAnalytics);
        }
    }catch(err) {};
}
/* ]]> */
// -->
</script>
<script type="text/javascript" src="/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/internal/jscript/dwanalytics-18.3.js" async="async" onload="trackPage()"></script>
<!-- Demandware Active Data (body_end-active_data.js) -->
<script src="/on/demandware.static/Sites-adidas-BR-Site/-/pt_BR/v1575016193036/internal/jscript/dwac-18.10.4.js" type="text/javascript" async="async"></script><!-- CQuotient Activity Tracking (body_end-cquotient.js) -->
<script src="https://cdn.cquotient.com/js/v2/gretel.min.js" type="text/javascript" async="async"></script>
<script type="text/javascript">var _cf = _cf || []; _cf.push(['_setFsp', true]); _cf.push(['_setBm', true]); _cf.push(['_setAu', '/assets/b9619c1c1915143aba953681d52d']);</script><script type="text/javascript" src="/assets/b9619c1c1915143aba953681d52d"></script>
<div id="monetateTrigger"></div><div id="ZN_6McRij6XnCfajoF"></div><div style="display: none;"><img src="https://nova.collect.igodigital.com/c2/10977635/track_page_view?payload=%7B%22title%22%3A%22adidas%20Brasil%20%7C%20Site%20Oficial%22%2C%22url%22%3A%22https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCOSummary2-Start%22%2C%22referrer%22%3A%22https%3A%2F%2Fwww.adidas.com.br%2Fon%2Fdemandware.store%2FSites-adidas-BR-Site%2Fpt_BR%2FCODelivery-Start%22%2C%22user_info%22%3A%7B%22email%22%3A%22%22%2C%22details%22%3A%7B%22country_code%22%3A%22BR%22%7D%7D%7D" width="0" height="0" title="blank image" aria-hidden="true" style="display: none;"></div><script src="https://siteintercept.qualtrics.com/dxjsmodule/CoreModule.js?Q_CLIENTVERSION=1.15.2&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/UserDefinedHTMLModule.js?Q_CLIENTVERSION=1.15.2&amp;Q_CLIENTTYPE=web" defer=""></script><script src="https://siteintercept.qualtrics.com/dxjsmodule/SliderModule.js?Q_CLIENTVERSION=1.15.2&amp;Q_CLIENTTYPE=web" defer=""></script><style type="text/css">.QSISlider div,.QSISlider dl,.QSISlider dt,.QSISlider dd,.QSISlider ul,.QSISlider ol,.QSISlider li,.QSISlider h1,.QSISlider h2,.QSISlider h3,.QSISlider h4,.QSISlider h5,.QSISlider h6,.QSISlider pre,.QSISlider form,.QSISlider fieldset,.QSISlider textarea,.QSISlider p,.QSISlider blockquote,.QSISlider th,.QSISlider td {margin: 0;padding: 0;color: black;font-family: arial;font-size: 12px;line-height: normal;}.QSISlider ul {margin: 12px 0;padding-left: 40px;}.QSISlider ol,.QSISlider ul {margin: 12px 0;padding-left: 40px;}.QSISlider ul li {list-style-type: disc;}.QSISlider ol li {list-style-type: decimal;}.QSISlider .scrollable {-webkit-overflow-scrolling: touch;}.QSISlider table {border-collapse: collapse;border-spacing: 0;}.QSISlider table td {padding: 2px;}.QSIPopOver *,.QSISlider *,.QSIPopUnder *,.QSIEmbeddedTarget * {box-sizing: content-box;}</style></body></html>